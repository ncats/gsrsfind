﻿var GSRSAPI = {
    builder: function () {
        var g_api = {};
        g_api.GlobalSettings = {
            _url: "https://ginas.ncats.nih.gov/ginas/app/api/v1/",
            _status: "OK", //set to ERROR when there's a problem
            _errorMessage: "",
            getBaseURL: function () {
                return g_api.GlobalSettings._url;
            },
            setBaseURL: function (url) {
                g_api.GlobalSettings._url = url;
                return g_api.GlobalSettings;
            },
            getHomeURL: function () {
                return g_api.GlobalSettings.getBaseURL().replace(/api.v1.*/g, "");
            },
            httpType: function () {
                return "jsonp"; //get only
                //return "json"; //CORS needed, updates possible 
            },
            authToken: null,
            authenticate: function (req) {
                req.headers = {};
                //push token header for now
                var tok = g_api.GlobalSettings.authToken;
                if (tok !== null) {
                    req.headers["auth-token"] = tok;
                }
            },
            getStatus: function () {
                return GlobalSettings._status;
            },
            setStatus: function (newStatus) {
                GlobalSettings._status = newStatus;
                console.log('Setting status to ' + newStatus);
            },
            getErrorMessage: function () {
                return GlobalSettings._errorMessage;
            }
        };

        //TODO: should be its own service
        g_api.httpProcess = function (req) {
            return g_api.JPromise.of(function (cb) {
                var b = req._b;
                if (b) {
                    b = JSON.stringify(b);
                } else {
                    b = req._q;
                }
                if (req._url.match(/.*[?]/)) {
                    req._url = req._url + "&cache=" + g_api.UUID.randomUUID();
                } else {
                    req._url = req._url + "?cache=" + g_api.UUID.randomUUID();
                }
                g_api.GlobalSettings.authenticate(req);

                console.log("called:" + req._url);
                $.ajax({
                    url: req._url,
                    jsonp: "callback",
                    dataType: GlobalSettings.httpType(),
                    contentType: 'application/json',
                    type: req._method,
                    data: b,
                    beforeSend: function (request) {
                        console.log('beforeSend at ' + _.now());

                        if (req.headers) {
                            _.forEach(_.keys(req.headers), function (k) {
                                request.setRequestHeader(k, req.headers[k]);
                            });
                        }
                    },
                    isJson: function (str) {
                        try {
                            JSON.parse(str);
                        }
                        catch (e) {
                            console.log('	error in isJson: ' + e);
                            return false;
                        }
                        return true;
                    },
                    success: function (response) {
                        console.log('ajax call success ');
                        console.log('	at ' + _.now());
                        cb(response);
                    },
                    error: function (response, error, t) {
                        var msg = 'Error from server. response: '
                            + JSON.stringify(response) + '; error: '
                            + JSON.stringify(error) + '\t' + '; t:' + t;
                        console.log(msg);


                        if ((response.status >= 400 && response.status <= 600) || (response.status == 0)) {
                            if (response.status == 500 && response.responseText === "java.lang.reflect.InvocationTargetException"
                                && response.readyState == 4) {
                                //not necessarily an error.
                                // This message occurs when we attempt to retrieve a section from a substance 
                                // that does not have that type of section (e.g., a protein does not have a molfile)
                                console.log('500 error');


                            } else {
                                GlobalSettings.setStatus("ERROR " + response.status);
                            }
                        }
                        GlobalSettings._errorMessage = error;
                        //figure out the message that will be displayed to the user in Excel
                        if (response.responseText) {
                            console.log('Noting error. ');
                            GlobalSettings._errorMessage = response.responseText;
                            console.log('	just set errorMessage');
                            var retMsg = { valid: false };

                            console.log('	initialized retMsg');
                            //detect a complex, nested error message
                            if (typeof (response.responseText) == 'string' && this.isJson(response.responseText)) {
                                var responseRestored = JSON.parse(response.responseText);
                                console.log(' parsed JSON');
                                if (responseRestored.validationMessages && responseRestored.validationMessages.length > 0) {
                                    console.log('	error msg: ' + responseRestored.validationMessages[0].message);
                                    retMsg.message = responseRestored.validationMessages[0].message;
                                    GlobalSettings._errorMessage = responseRestored.validationMessages[0].message;
                                    if (responseRestored.validationMessages.length > 1) {
                                        retMsg.message = retMsg.message + ' + more';
                                        GlobalSettings._errorMessage = GlobalSettings._errorMessage + '...';
                                    }

                                }
                                else if (responseRestored.message) {
                                    retMsg.message = responseRestored.message;
                                    GlobalSettings._errorMessage = responseRestored.message;
                                }
                                else retMsg.message = "unparsed error";
                            }
                            else if (typeof (response.responseText) == 'object' && response.responseText.message) {
                                console.log(' object');
                                retMsg.message = response.responseText.message;
                                if (response.status == 502) {
                                    console.log('502; proxy error');
                                    retMsg.message = 'proxy error on server. Please report this to your administrator!';
                                }


                            }
                            else {
                                console.log(' simple message. response.status: ' + response.status);
                                //simple message
                                retMsg.message = response.responseText;
                                if (response.status == 502) {
                                    console.log('502; proxy error');
                                    retMsg.message = 'proxy error on server. Please report this to your administrator!';
                                }
                            }
                            console.log(' about to invoke cb');
                            cb(retMsg);

                        }
                        else {
                            console.log('Error missing');
                            cb(response);
                        }
                    }
                });
            });
        };

        //Returns an object which will call
        //the supplied callback after {{total}}
        //number of calls to {{decrement}}
        g_api.getListener = function (total, cb) {
            return {
                total: total,
                current: 0,
                callback: cb,
                decrement: function () {
                    this.current++;
                    if (this.current >= this.total) {
                        this.callback();
                    }
                }
            };
        }

        g_api.JPromise = {
            ofScalar: function (s) {
                return g_api.JPromise.of(function (cb) {
                    cb(s);
                });
            },
            of: function (calc) {
                var ret = {
                    get: function (cb) {
                        calc(cb);
                    },
                    andThen: function (lam) {
                        return g_api.JPromise.of(function (cb) {
                            ret.get(function (orig) {
                                var ret = lam(orig);
                                if (ret && ret._promise) {
                                    ret.get(cb);
                                } else if (typeof ret === "undefined") {
                                    cb(orig);
                                } else {
                                    cb(ret);
                                }
                            });
                        });
                    },
                    _promise: true
                };
                return ret;
            },

            join: function (listo) {
                var list = [];
                if (arguments.length > 1) {
                    list = arguments;
                } else {
                    list = listo;
                }
                return g_api.JPromise.of(function (cb) {
                    var toRet = {};
                    var retFun = function () {
                        var retList = [];
                        for (var j = 0; j < list.length; j++) {
                            retList.push(toRet[j]);
                        }
                        return retList;
                    };
                    var listener = g_api.getListener(list.length, function () {
                        cb(retFun());
                    });
                    var proc = function (pFetch, key) {
                        pFetch.get(function (ret) {
                            toRet[key] = ret;
                            listener.decrement();
                        });
                    };
                    for (var i = 0; i < list.length; i++) {
                        var pFetch = list[i];
                        proc(pFetch, i);
                    }
                });
            }
        };

        g_api.gUtil = {
            empty: {},

            deepIterate: function (o, path, cb) {
                if (_.isFunction(o)) {
                    return g_api.gUtil.empty;
                } else if (_.isObject(o)) {
                    if (_.isArray(o)) {
                        var ks = _.keys(o);
                        _.forEach(ks, function (k) {
                            g_api.gUtil.deepIterate(o[k], path + "[" + k + "]", cb);
                        });
                    } else {
                        var ks = _.keys(o);
                        _.forEach(ks, function (k) {
                            g_api.gUtil.deepIterate(o[k], path + "/" + k, cb);
                        });
                    }
                } else {
                    cb(path, o);
                }
            },
            forEachDeep: function (o, path, cb) {
                var node = function (path, key, value, parent) {
                    return {
                        path: path,
                        key: key,
                        value: value,
                        parent: parent
                    };
                };
                if (_.isFunction(o)) {
                    return g_api.gUtil.empty;
                } else if (_.isObject(o)) {
                    if (_.isArray(o)) {
                        var ks = _.keys(o);
                        var mod = false;
                        _.forEach(ks, function (k) {
                            var rep = cb(node(path, k, o[k], o));
                            if (rep == g_api.gUtil.empty) {
                                o[k] = g_api.gUtil.empty;
                                mod = true;
                            } else {
                                if (typeof rep !== "undefined") {
                                    o[k] = rep;
                                }
                                g_api.gUtil.forEachDeep(o[k], path + "/" + k, cb);
                            }
                        });
                        if (mod) {
                            var newArray = _.filter(o, function (e) {
                                if (e == g_api.gUtil.empty)
                                    return false;
                                return true
                            });
                            o.splice(0, o.length);
                            _.forEach(newArray, function (a) {
                                o.push(a);
                            });
                        }
                    } else {
                        var ks = _.keys(o);
                        _.forEach(ks, function (k) {
                            var rep = cb(node(path, k, o[k], o));
                            if (rep === gUtil.empty) {
                                delete o[k];
                            } else {
                                if (typeof rep !== "undefined") {
                                    o[k] = rep;
                                }
                                g_api.gUtil.forEachDeep(o[k], path + "/" + k, cb);
                            }
                        });
                    }
                }
            },
            removeDeep: function (o, test) {
                g_api.gUtil.forEachDeep(o, "", function (node) {
                    if (test(node)) {
                        return gUtil.empty;
                    }
                });
            },
            removeKeysLike: function (o, regex) {
                g_api.gUtil.removeDeep(o, function (node) {
                    return node.key.match(regex);
                });
            },
            toDate: function (d) {
                return new Date(d);
            }
        };

        g_api.ResourceFinder = {
            builder: function () {
                var finder = {};
                finder.resource = function (resource) {
                    finder.resource = resource;
                    return finder;
                };
                finder.searcher = function () {
                    return g_api.SearchRequest.builder()
                        .resource(finder.resource);
                };
                finder.search = function (q) {
                    return finder.searcher()
                        .query(q)
                        .execute();
                };
                finder.get = function (uuid) {
                    alert('starting in finder.get with uuid ' + uuid);
                    var req = g_api.Request.builder()
                        .url(g_api.GlobalSettings.getBaseURL() + finder.resource + "(" + uuid + ")");

                    return g_api.httpProcess(req).andThen(function (sim) {
                        //TODO: make generic
                        return g_api.SubstanceBuilder.fromSimple(sim);
                    });
                };

                finder.extend = function (f) {
                    var nfinder = f(finder);
                    if (typeof nfinder !== "undefined") {
                        return nfinder;
                    } else {
                        return finder;
                    }
                };

                return finder;
            }
        };

        g_api.SubstanceFinder = g_api.ResourceFinder.builder()
            .resource("substances")
            .extend(function (sfinder) {
                sfinder.searchByExactNameOrCode = function (q) {
                    if (UUID.isUUID(q)) {
                        return sfinder.get(q).andThen(function (s) {
                            return { "content": [s] }
                        });
                    }
                    return sfinder.search("root_names_name:\"^" + q + "$\" OR " +
                        "root_approvalID:\"^" + q + "$\" OR " +
                        "root_codes_code:\"^" + q + "$\"");
                };
                sfinder.getExactStructureMatches = function (smi) {
                    //substances/structureSearch?q=CCOC(N)=O&type=exact
                    var req = g_api.Request.builder()
                        .url(g_api.GlobalSettings.getBaseURL() + "substances/structureSearch")
                        .queryStringData({
                            q: smi,
                            type: "exact",
                            sync: "true" //shouldn't be sync
                        });
                    return g_api.httpProcess(req).andThen(function (tmp) {
                        return tmp;
                    });
                };

                sfinder.searchByExactName = function (q) {
                    return sfinder.search("root_names_name:\"^" + q + "$\"");
                };
            });
        g_api.ReferenceFinder = g_api.ResourceFinder.builder()
            .resource("references")
            .extend(function (rfinder) {
                rfinder.searchByLastEdited = function (q) {
                    return rfinder.search("root_lastEditedBy:\"^" + q + "$\"");
                };
            });

        g_api.CVFinder = g_api.ResourceFinder.builder()
            .resource("vocabularies")
            .extend(function (cvfinder) {
                cvfinder.searchByDomain = function (q) {
                    return cvfinder.search("root_domain:\"^" + q + "$\"");
                };
            });

        g_api.SearchRequest = {
            builder: function () {
                var request = {
                    _limit: 10,
                    _skip: 0,
                    _resource: "resource",
                    _query: ""
                };
                request.limit = function (limit) {
                    request._limit = limit;
                    return request;
                };
                request.skip = function (skip) {
                    request._skip = skip;
                    return request;
                };
                request.top = function (top) {
                    return request.limit(top);
                };
                request.resource = function (resource) {
                    request._resource = resource;
                    return request;
                };
                request.query = function (q) {
                    request._query = q;
                    return request;
                };
                request.asRequest = function () {
                    return g_api.Request.builder()
                        .url(g_api.GlobalSettings.getBaseURL() + request._resource + "/search")
                        .queryStringData({
                            q: request._query,
                            top: request._limit,
                            skip: request._skip
                        });
                };
                request.execute = function () {
                    var httpreq = request.asRequest();
                    return g_api.httpProcess(httpreq);
                };
                return request;
            }
        };


        //TODO
        g_api.SearchResponse = {
            builder: function () {
                var resp = {};
                resp.mix = function (raw) {
                    _.merge(resp, raw);
                    return resp;
                };
                return resp;
            }
        };

        g_api.SubstanceBuilder = {
            fromSimple: function (simple) {
                simple._cache = {};
                simple.getBestID = function () {
                    if (simple._approvalIDDisplay) {
                        return simple._approvalIDDisplay;
                    } else {
                        return simple.uuid;
                    }
                };
                simple.full = function () {
                    //if this is a new record, return self
                    if (!simple.uuid) {
                        return g_api.JPromise.ofScalar(simple);
                    }
                    var req = Request.builder()
                        .url(g_api.GlobalSettings.getBaseURL() + "substances(" + simple.uuid + ")")
                        .queryStringData({
                            view: "full"
                        });
                    return g_api.httpProcess(req);
                };
                simple.fetch = function (field, lambda) {
                    var ret = simple._cache[field];
                    var p = null;
                    if (!ret) {
                        var url = g_api.GlobalSettings.getBaseURL() + "substances(" + simple.uuid + ")/";
                        if (field) {
                            url += field;
                        }
                        var req = g_api.Request.builder()
                            .url(url);
                        p = g_api.httpProcess(req);
                    } else {
                        p = g_api.JPromise.ofScalar(ret);
                    }
                    if (lambda) {
                        return p.andThen(lambda);
                    }
                    return p;
                };
                simple.patch = function () {
                    var p = Patch.builder();

                    if (!simple.uuid) {
                        p = p.setMethod("POST");
                    }

                    //patch overrides but calls the base method
                    p._oldApply = p.apply;
                    p._oldCompute = p.compute;
                    p._oldValidate = p.validate;
                    p.apply = function () {
                        return p._oldApply(simple);
                    };
                    p.compute = function () {
                        return p._oldCompute(simple);
                    };
                    p.validate = function () {
                        return p._oldValidate(simple);
                    };
                    return p;
                };
                return simple;
            }
        };

        g_api.Patch = {
            builder: function () {
                var b = {
                    ops: []
                };

                b.change = function (op) {
                    b.ops.push(op);
                    return b;
                };

                b.replace = function (path, n) {
                    return b.change({
                        op: "replace",
                        path: path,
                        value: n
                    });
                };

                b.remove = function (path) {
                    return b.change({
                        op: "remove",
                        path: path
                    });
                };

                b._method = "PUT";

                //change the method type
                b.setMethod = function (meth) {
                    b._method = meth;
                    return b;
                };

                //Method below is a shot in the dark. TODO: verify!
                b.update = function (path) {
                    return b.change({
                        op: "update",
                        path: path
                    });
                };

                b.add = function (path, n) {
                    return b.change({
                        op: "add",
                        path: path,
                        value: n
                    });
                };

                b.addData = function (data) {
                    return data.addToPatch(b);
                };

                //should return a promise
                b.apply = function (simpleSub) {
                    return simpleSub.full()
                        .andThen(function (ret) {
                            var rr = ret;
                            jsonpatch.apply(rr, b.ops);
                            var methodText = ((b._method) ? b._method : "PUT");
                            console.log('methodText: ' + methodText);
                            var req = g_api.Request.builder()
                                .url(g_api.GlobalSettings.getBaseURL() + "substances")
                                .method(methodText)
                                .body(rr);

                            return g_api.httpProcess(req)
                                //new lines 30 June 2017
                                .andThen(function (r) {
                                    if (r === "") {
                                        return { valid: false, message: "Unexpected error from server" };
                                    } else {
                                        return r;
                                    }
                                });
                        });
                };

                //Calculates the new record, does not submit it
                b.compute = function (simpleSub) {
                    return simpleSub.full()
                        .andThen(function (ret) {
                            var rr = ret;
                            jsonpatch.apply(rr, b.ops);
                            return rr;
                        });
                };

                //Calculates the new record, does not submit it
                b.validate = function (simpleSub) {
                    return simpleSub.full()
                        .andThen(function (ret) {
                            var rr = ret;
                            jsonpatch.apply(rr, b.ops);
                            var req = g_api.Request.builder()
                                .url(g_api.GlobalSettings.getBaseURL() + "substances/@validate")
                                .method("POST")
                                .body(rr);
                            return g_api.httpProcess(req);
                        });
                };

                return b;
            }
        };

        g_api.ResolveWorker = {
            builder: function () {
                var worker = {
                    _list: [],
                    _fetchers: [],
                    _consumer: function (r) { },
                    _finisher: function () { },
                    consumer: function (c) {
                        worker._consumer = c;
                        return worker;
                    },
                    list: function (l) {
                        worker._list = l;
                        return worker;
                    },
                    fetchers: function (f) {
                        worker._fetchers = f;
                        return worker;
                    },
                    finisher: function (f) {
                        worker._finisher = f;
                        return worker;
                    },
                    resolve: function () {
                        var psubs = _.chain(worker._list)
                            .filter(function (r) {
                                return (r.length > 0);
                            })
                            .map(function (r) {
                                var pSub = g_api.SubstanceFinder.searchByExactNameOrCode(r);
                                pSub._q = r;
                                return pSub;
                            })
                            .value();

                        var listener = getListener(psubs.length, function () {
                            worker._finisher();
                        });

                        _.forEach(psubs, function (pSub) {
                            worker.process(pSub, worker._fetchers).get(function (rows) {
                                _.forEach(rows, function (row) {
                                    worker._consumer(row);
                                });
                                listener.decrement();
                            });
                        });
                    },
                    process: function (pSub, fetchNames) {
                        var row = pSub._q;
                        return pSub.andThen(function (ret) {
                            return ret["content"];
                        })
                            .andThen(function (content) {
                                if (content && content.length > 0) {
                                    var promises = _.map(content, function (c) {
                                        return worker.outputAll(g_api.SubstanceBuilder.fromSimple(c), fetchNames);
                                    });
                                    return g_api.JPromise.join(promises).andThen(function (all) {
                                        return _.map(all, function (q) {
                                            return row + "\t" + q;
                                        });
                                    });
                                } else {
                                    return g_api.JPromise.ofScalar([row]);
                                }
                            });
                    },
                    outputAll: function (simpleSub, fetchNames) {
                        return g_api.JPromise.of(function (cb) {
                            g_api.FetcherRegistry.getFetchers(fetchNames)
                                .fetcher(simpleSub)
                                .get(function (g) {
                                    cb(g.join("\t"));
                                });
                        });
                    }
                };
                return worker;
            }
        };

        //TODO: convert to builder pattern
        g_api.FetcherMaker = {
            make: function (name, maker) {
                var fetcher = {
                    name: name,
                    tags: [],
                    fetcher: function (simp) {
                        return g_api.JPromise.of(function (cb) {
                            maker(simp).get(function (ret) {
                                cb(ret, name);
                            });
                        });
                    },
                    andThen: function (after) {
                        return g_api.FetcherMaker.make(name, function (simp) {
                            return fetcher.fetcher(simp).andThen(after);
                        });
                    }
                };
                fetcher.addTag = function (tag) {
                    fetcher.tags.push(tag);
                    return fetcher;
                };
                fetcher.setDescription = function (desc) {
                    fetcher.description = desc;
                    return fetcher;
                };
                return fetcher;
            },
            makeAPIFetcher: function (property, name) {
                var nm = name;
                if (!nm) {
                    nm = property;
                }
                return g_api.FetcherMaker.make(nm, function (simpleSub) {
                    return simpleSub.fetch(property);
                });
            },
            makeScalarFetcher: function (property, name) {
                var nm = name;
                if (!nm) {
                    nm = property;
                }
                return g_api.FetcherMaker.make(nm, function (simpleSub) {
                    return g_api.JPromise.ofScalar(simpleSub[property]);
                });
            },
            makeCodeFetcher: function (codeSystem, name) {
                var nm = name;
                if (!nm) {
                    nm = codeSystem + "[CODE]"
                }
                return g_api.FetcherMaker.make(nm, function (simpleSub) {
                    return simpleSub.fetch("codes(codeSystem:" + codeSystem + ")")
                        .andThen(function (cds) {
                            return _.chain(cds)
                                .sort(function (a, b) {
                                    if (a.type === "PRIMARY" && b.type !== "PRIMARY") {
                                        return -1;
                                    } else if (a.type !== "PRIMARY" && b.type === "PRIMARY") {
                                        return 1
                                    } else {
                                        return 0;
                                    }
                                })
                                .map(function (cd) {
                                    if (cd.type !== "PRIMARY") {
                                        return cd.code + " [" + cd.type + "]";
                                    } else {
                                        return cd.code;
                                    }
                                })
                                .value()
                                .join("; ");
                        });
                });
            }
        };

        g_api.FetcherRegistry = {
            fetchMap: {},
            getFetcher: function (name) {
                var ret = g_api.FetcherRegistry.fetchMap[name];
                return ret;
            },
            addFetcher: function (fetcher) {
                g_api.FetcherRegistry.fetchMap[fetcher.name] = fetcher;
                g_api.FetcherRegistry.fetchers.push(fetcher);
                return g_api.FetcherRegistry;
            },
            fetchers: [],
            //Actually accumulates into a master fetcher 
            getFetchers: function (list) {
                var retlist = _.map(list, function (f) {
                    return g_api.FetcherRegistry.getFetcher(f);
                });
                return g_api.FetcherRegistry.joinFetchers(retlist);
            },
            joinFetchers: function (retlist) {
                return g_api.FetcherMaker.make("Custom", function (simpleSub) {
                    var proms = _.map(retlist, function (r) {
                        return r.fetcher(simpleSub);
                    });
                    var promNames = _.map(retlist, function (r) {
                        return r.name;
                    });

                    return g_api.JPromise.of(function (callback) {
                        g_api.JPromise.join(proms)
                            .get(function (array) {
                                callback(array, promNames);
                            });
                    });
                });
            },
            getFetcherTags: function () {
                var allTags = [];
                _.chain(g_api.FetcherRegistry.fetchers)
                    .map(function (f) {
                        return f.tags;
                    })
                    .forEach(function (tgs) {
                        _.forEach(tgs, function (t) {
                            allTags.push(t);
                        });
                    }).value();
                return _.uniq(allTags);
            },
            getFetchersWithTag: function (tag) {
                return _.chain(g_api.FetcherRegistry.fetchers)
                    .filter(function (f) {
                        return _.indexOf(f.tags, tag) >= 0;
                    })
                    .value();
            },
            getFetchersWithNoTag: function () {
                return _.chain(g_api.FetcherRegistry.fetchers)
                    .filter(function (f) {
                        return f.tags.length === 0;
                    })
                    .value();
            }
        };

        var UUID = {
            randomUUID: function () {
                return UUID.s4() + UUID.s4() + '-' + UUID.s4() + '-' + UUID.s4() + '-' +
                    UUID.s4() + '-' + UUID.s4() + UUID.s4() + UUID.s4();
            },
            s4: function () {
                return Math.floor((1 + Math.random()) * 0x10000)
                    .toString(16)
                    .substring(1);
            },
            isUUID: function (uuid) {
                if ((uuid + "").match(/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/)) {
                    return true;
                }
                return false;
            }
        };

        g_api.UUID = UUID;

        g_api.Request = {
            builder: function () {
                var rq = {
                    _method: "GET"
                };

                rq.url = function (url) {
                    rq._url = url;
                    return rq;
                };
                rq.method = function (method) {
                    rq._method = method;
                    return rq;
                };
                rq.queryStringData = function (q) {
                    rq._q = q;
                    return rq;
                };
                rq.body = function (b) {
                    rq._b = b;
                    return rq;
                };
                return rq;
            }
        };

        //********************************
        //Models
        //********************************

        var CommonData = {
            builder: function () {
                var data = {};

                //should be set
                data._path = "";
                data._type = "";

                //default values
                data.uuid = UUID.randomUUID();
                data.references = [];
                data.access = [];
                data._references = [];

                data.build = function () {
                    var d = JSON.parse(JSON.stringify(data));
                    g_api.gUtil.removeKeysLike(d, /^_/);
                    return d;
                };

                data.setAccess = function (list) {
                    data.access = list;
                    return data;
                };

                data.setProtected = function () {
                    console.log('setProtected called');
                    data.access = ["protected"];
                    return data;
                };

                data.setPublic = function (pub) {
                    if (pub) {
                        console.log('setPublic perceived pub as true. pub: ' + pub);
                        return data;
                    }
                    console.log('setPublic pub as false.');
                    return data.setProtected();
                };

                data.setPreferred = function (preferred) {
                    data.preferred = true;
                    return data;
                };

                data.setDeprecated = function (d) {
                    if (d) {
                        data.deprecated = true;
                    } else {
                        data.deprecated = false;
                    }
                    return data;
                };

                data.addReference = function (r) {
                    if (UUID.isUUID(r)) {
                        data.addReferenceUUID(r);
                    } else {
                        if (r._type === "reference") {
                            data._references.push(r);
                            data.addReferenceUUID(r.uuid);
                        } else {
                            var ref = _.merge(Reference.builder(), r);
                            data._references.push(ref);
                            data.addReferenceUUID(ref.uuid);
                        }
                    }
                    return data;
                };

                data.addReferenceUUID = function (ruuid) {
                    data.references.push(ruuid);
                    return data;
                };

                data.addToPatch = function (patch) {
                    patch = patch.add(data._path, data.build());
                    _.forEach(data._references, function (r) {
                        patch = patch.add("/references/-", r.build());
                    });
                    return patch;
                };

                data.mix = function (source) {
                    _.merge(data, source);
                    return data;
                };

                return data;
            }
        };

        var Name = {
            builder: function () {
                var name = CommonData.builder();
                name._type = "name";
                name._path = "/names/-";

                name.type = "cn";
                name.setName = function (nm) {
                    name.name = nm;
                    return name;
                };
                name.setType = function (type) {
                    name.type = type;
                    return name;
                };
                name.setLanguages = function (lng) {
                    name.languages = lng;
                    return name;
                };
                name.setDomains = function (dmns) {
                    name.domains = dmns;
                    return name;
                };
                name.setNameOrgs = function (orgs) {
                    name.nameOrgs = orgs;
                    return name;
                };


                return name;
            }
        };
        var Code = {
            builder: function () {
                var code = CommonData.builder();
                code._type = "code";
                code._path = "/codes/-";

                code.type = "cn";
                code.setCode = function (cd) {
                    code.code = cd;
                    return code;
                };
                code.setType = function (type) {
                    code.type = type;
                    return code;
                };
                code.setCodeSystem = function (sys) {
                    code.codeSystem = sys;
                    return code;
                };
                code.setCodeComments = function (cmt) {
                    code.comments = cmt;
                    return code;
                };
                code.setUrl = function (url) {
                    code.url = url;
                    return code;
                };

                return code;
            }
        };

        var Reference = {
            builder: function () {
                var ref = CommonData.builder();
                ref._type = "reference";
                ref._path = "references/-";

                ref.setCitation = function (cit) {
                    ref.citation = cit;
                    return ref;
                }
                ref.setUrl = function (url) {
                    ref.url = url;
                    return ref;
                }
                ref.setDocType = function (typ) {
                    ref.docType = typ;
                    return ref;
                }
                ref.setPublicDomain = function (pd) {
                    ref.publicDomain = pd;
                    return ref;
                }

                //@Override
                var oldBuild = ref.build;
                ref.build = function () {
                    var d = oldBuild();
                    delete d.references;
                    return d;
                }
                return ref;
            }
        };

        var Relationship = {
            builder: function () {
                var relationship = CommonData.builder();
                relationship._type = "relationship";
                relationship._path = "/relationships/-";

                relationship.setType = function (type) {
                    relationship.type = type;
                    return relationship;
                };
                relationship.setRelatedSubstance = function (sys) {
                    relationship.relatedSubstance = {
                        "substanceClass": "reference",
                        "refPname": sys._name, "refuuid": sys.uuid, "approvalID": sys.approvalID
                    };
                    var msg = 'in setRelatedSubstance, set refPname to ' + sys._name
                        + '; refuuid to ' + sys.uuid + '; approvalID to ' + sys.approvalID;
                    //alert(msg);
                    return relationship;
                };
                return relationship;
            }
        };

        g_api.CommonData = CommonData;
        g_api.Name = Name;
        g_api.Code = Code;
        g_api.Reference = Reference;
        g_api.Relationship = Relationship;

        var Scripts = {
            scriptMap: {},
            addScript: function (s) {
                Scripts.scriptMap[s.name] = s;
                return Scripts;
            },
            get: function (nm) {
                return Scripts.scriptMap[nm];
            },
            all: function () {
                return _.chain(_.keys(Scripts.scriptMap))
                    .map(function (s) {
                        return Scripts.scriptMap[s];
                    })
                    .value();
            }
        };

        var Script = {
            builder: function () {
                var scr = {};
                scr.argMap = {};
                scr.arguments = [];
                scr.addArgument = function (arg) {
                    if (arg._type !== "argument") {
                        arg = Argument.builder().mix(arg);
                    }
                    scr.arguments.push(arg);
                    scr.argMap[arg.getKey()] = arg;
                    return scr;
                };
                scr.setKey = function (key) {
                    scr.key = key;
                    return scr;
                };
                scr.setName = function (name) {
                    scr.name = name;
                    return scr;
                };
                scr.setDescription = function (desc) {
                    scr.description = desc;
                    return scr;
                };
                scr.mix = function (sc) {
                    _.merge(scr, sc);
                    _.forEach(scr.arguments, function (a) {
                        scr.argMap[a.getKey()] = a;
                    });
                    return scr;
                };
                scr.getArgument = function (narg) {
                    return scr.argMap[narg];
                };

                scr.getArgumentByName = function (narg) {
                    var l = _.filter(scr.arguments, function (a) {
                        return a.name === narg
                    });
                    if (l.length == 0)
                        return undefined;
                    return l[0];
                };
                scr.hasArgumentByName = function (narg) {
                    return !(typeof scr.getArgumentByName(narg) === "undefined");
                };
                scr.hasArgument = function (narg) {
                    return !(typeof scr.getArgument(narg) === "undefined");
                };

                scr.setExecutor = function (exec) {
                    scr.executor = exec;
                    return scr;
                };
                scr.useFor = function (cb) {
                    cb(scr);
                };

                //should return a promise
                //takes a 
                scr.execute = function (vals) {
                    return g_api.JPromise.of(function (cb) {
                        var ret = scr.executor(vals);
                        if (ret && ret._promise) {
                            ret.get(cb);
                        } else {
                            cb(ret);
                        }
                    });

                };
                scr.runner = function () {
                    var cargs = {
                        args: {}
                    };
                    cargs.setValue = function (key, value) {
                        var darg = scr.getArgument(key);
                        if (!darg) {
                            throw "No such argument '" + key + "' in script '" + scr.name + "'";
                        }
                        cargs.args[key] = Argument.builder().mix(scr.getArgument(key)).setValue(value);
                        return cargs;
                    };
                    cargs.setValues = function (kvpairs) {
                        _.forEach(_.keys(kvpairs), function (k) {
                            cargs.setValue(k, kvpairs[k]);
                        });
                        return cargs;
                    };
                    cargs.getArguments = function () {
                        var ret = [];
                        _.forEach(_.keys(cargs.args), function (k) {
                            ret.push(cargs.args[k]);
                        });
                        return ret;
                    };
                    _.forEach(scr.arguments, function (a) {
                        cargs.args[a.getKey()] = a;
                    });


                    cargs.validate = function () {
                        var proms = _.chain(cargs.getArguments())
                            .map(function (a) {
                                return a.validate(cargs);
                            })
                            .value();
                        return g_api.JPromise.join(proms)
                            .andThen(function (plist) {
                                var invalid = _.chain(plist)
                                    .filter(function (v) {
                                        return !v.valid;
                                    })
                                    .value();
                                return invalid;
                            });

                    };

                    cargs.execute = function () {

                        return cargs.validate()
                            .andThen(function (v) {
                                if (v.length == 0) {
                                    return scr.execute(cargs.args)
                                        .andThen(function (r) {
                                            if (typeof r.valid === "undefined") {
                                                return { "valid": true, "message": "Success", "returned": r };
                                            } else {
                                                return r;
                                            }
                                        });
                                } else {

                                    var msg = _.chain(v)
                                        .map(function (mv) {
                                            return mv.message;
                                        })
                                        .value()
                                        .join(";");
                                    return { "valid": false, "message": msg };
                                }
                            })
                    };
                    return cargs;
                };

                return scr;
            }
        };

        var Argument = {
            builder: function () {
                var arg = {};
                arg._type = "argument";
                arg.opPromise = JPromise.ofScalar([]);
                //name of the argument
                arg.setName = function (nm) {
                    arg.name = nm;
                    return arg;
                };

                arg.getName = function () {
                    return arg.name;
                };
                arg.mix = function (ar) {
                    return _.merge(arg, ar);
                };

                arg.validator = function (v) {
                    return g_api.JPromise.ofScalar({ valid: true });
                };

                arg.setRequired = function (r) {
                    arg.required = r;
                    return arg;
                };
                arg.setOptions = function (opPromise) {
                    if (opPromise._promise) {
                        arg.opPromise = opPromise;
                    } else {
                        arg.opPromise = JPromise.ofScalar(opPromise);
                    }
                    return arg;
                };
                arg.getOptions = function () {
                    return arg.opPromise;
                };
                arg.getKey = function () {
                    if (arg.key) {
                        return arg.key;
                    }
                    return arg.name;
                };

                //
                arg.validate = function (cargs) {
                    var validFunction = arg.validator(arg.getValue(), cargs);

                    if (arg.required) {
                        if (_.isUndefined(arg.getValue()) || arg.getValue() === "") {
                            return g_api.JPromise.ofScalar({
                                "valid": false,
                                "message": "Argument '" + arg.getName() + "' must be specified"
                            });
                        }
                    }

                    if (arg.type === "cv") {
                        return arg.opPromise.andThen(function (o) {
                            if (!_.includes(o, arg.getValue())) {
                                return {
                                    "valid": false,
                                    "message": "Argument '" + arg.getName() + "' has value '" + arg.getValue() + "' which is not in the CV"
                                };
                            }

                            return validFunction;
                        });
                    }

                    return validFunction;
                }

                arg.isRequired = function () {
                    if (arg.required) {
                        return true;
                    }
                    var typeVar = typeof arg.defaultValue;

                    return (typerVar === "undefined");

                };

                arg.setDescription = function (des) {
                    arg.description = des;
                    return arg;
                };

                arg.setType = function (type) {
                    arg.type = type;
                    return arg;
                };

                arg.setValue = function (value) {
                    arg.value = value;
                    return arg;
                };
                arg.setDefault = function (def) {
                    arg.defaultValue = def;
                    return arg;
                };
                arg.getValue = function () {
                    if (!_.isUndefined(arg.value)) {
                        return arg.value;
                    } else {
                        return arg.defaultValue;
                    }
                };
                return arg;
            }
        };
        g_api.Scripts = Scripts;
        g_api.Script = Script;
        g_api.Argument = Argument;

        GSRSAPI.initialize(g_api);

        return g_api;
    },
    initialize: function (g_api) {
        _.chain(GSRSAPI.extensions)
            .forEach(function (ex) {
                ex.init(g_api);
            });
    },
    addExtension: function (ext) {
        GSRSAPI.extensions.push(ext);
    },
    extensions: []
}


//Global Helpers
//For use in legacy code (should refactor)
var GGlob = GSRSAPI.builder();
var GlobalSettings = GGlob.GlobalSettings;
var getListener = GGlob.getListener;
var JPromise = GGlob.JPromise;
var gUtil = GGlob.gUtil;
var ResourceFinder = GGlob.ResourceFinder;
var SubstanceFinder = GGlob.SubstanceFinder;
var ReferenceFinder = GGlob.ReferenceFinder;
var SearchRequest = GGlob.SearchRequest;
var SubstanceBuilder = GGlob.SubstanceBuilder;
var Patch = GGlob.Patch;
var ResolveWorker = GGlob.ResolveWorker;
var FetcherMaker = GGlob.FetcherMaker;
var FetcherRegistry = GGlob.FetcherRegistry;
var UUID = GGlob.UUID;
var Request = GGlob.Request;

//TODO: Finish this
var Validation = {
    builder: function () {
        var v = {};
    }
}


//********************************
//Models
//********************************

var CommonData = GGlob.CommonData;
var Name = GGlob.Name;
var Code = GGlob.Code;
var Reference = GGlob.Reference;
var Relationship = GGlob.Relationship;

var Debug = {}


//I don't like this yet
//it's here as a quick and dirty way to make
//VBA have a simple recipe for doing predefined things
var Scripts = GGlob.Scripts;
var Script = GGlob.Script;
var Argument = GGlob.Argument;


//********************************
//Fetchers
//********************************

FetcherRegistry.addFetcher(
    FetcherMaker.make("Active Moiety PT", function (simpleSub) {
        return simpleSub.fetch("relationships")
            .andThen(function (r) {
                return _.chain(r)
                    .filter({ type: "ACTIVE MOIETY" })
                    .map(function (ro) {
                        return ro.relatedSubstance.refPname;
                    })
                    .value()
                    .join("|");
            });
    }).addTag("Substance")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Active Moiety ID", function (simpleSub) {
        return simpleSub.fetch("relationships")
            .andThen(function (r) {
                return _.chain(r)
                    .filter({ type: "ACTIVE MOIETY" })
                    .map(function (ro) {
                        return ro.relatedSubstance.approvalID;
                    })
                    .value()
                    .join("|");
            });
    }).addTag("Substance")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Smiles", function (simpleSub) {
        return simpleSub.fetch("structure/smiles");
    }).addTag("Chemical")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("InChIKey", function (simpleSub) {
        return simpleSub.fetch("structure!$inchikey()")
            .andThen(function (ik) {
                var iks = ik.split("=");
                if (iks.length > 1) {
                    return iks[1];
                } else {
                    return null;
                }
            });
    }).addTag("Chemical")
);


FetcherRegistry.addFetcher(
    FetcherMaker.make("Exact Test", function (simpleSub) {
        return simpleSub.fetch("structure/smiles")
            .andThen(function (smi) {
                return SubstanceFinder.getExactStructureMatches(smi)
                    .andThen(function (s) {
                        return _.chain(s.content)
                            .map(function (o) {
                                return o._name;
                            })
                            .value().join("|");
                    });
            });

    }).addTag("Tests")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Image URL", function (simpleSub) {
        var base = GlobalSettings.getBaseURL().replace(/api.*/g, "");
        var imgurl = base + "img/" + simpleSub.uuid + ".png?size=300";
        return JPromise.ofScalar(imgurl);
    })
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Protein Sequence", function (simpleSub) {
        return simpleSub.fetch("protein/subunits!(sequence)!join(;)");
    }).addTag("Protein")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("UUID", function (simpleSub) {

        return JPromise.ofScalar(simpleSub.uuid);
    }).addTag("Identifiers")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Lychi", function (simpleSub) {
        return simpleSub.fetch("structure/properties(label:LyChI_L4)($0)/term");
    }).addTag("Chemical")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Substance Class", function (simpleSub) {
        return JPromise.ofScalar(simpleSub.substanceClass);
    }).addTag("Substance")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Record Access", function (simpleSub) {
        return JPromise.ofScalar(simpleSub.access.join(";"));
    }).addTag("Record")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("All Names", function (simpleSub) {

        return simpleSub.fetch("names!(name)!join(|)").andThen(function (n) {
            return n.replace(/%7C/g, "|");
        });
    }).addTag("Substance")
);

FetcherRegistry.addFetcher(FetcherMaker.makeCodeFetcher("BDNUM").addTag("Identifiers"))
    .addFetcher(FetcherMaker.makeCodeFetcher("WHO-ATC", "ATC Code").addTag("Substance"))
    .addFetcher(FetcherMaker.makeCodeFetcher("CAS", "CAS Numbers").addTag("Identifiers"))
    .addFetcher(FetcherMaker.makeCodeFetcher("EVMPD", "EVMPD Code").addTag("Identifiers"));



FetcherRegistry.addFetcher(FetcherMaker.makeScalarFetcher("_name", "Preferred Term").addTag("Substance"))
    .addFetcher(FetcherMaker.makeScalarFetcher("_approvalIDDisplay", "Approval ID (UNII)").addTag("Identifiers"))
    .addFetcher(FetcherMaker.makeScalarFetcher("createdBy", "Created By").addTag("Record"))
    .addFetcher(FetcherMaker.makeScalarFetcher("created", "Created Date").andThen(gUtil.toDate).addTag("Record"))
    .addFetcher(FetcherMaker.makeScalarFetcher("lastEditedBy", "Last Edited By").addTag("Record"))
    .addFetcher(FetcherMaker.makeScalarFetcher("lastEdited", "Last Edited Date").andThen(gUtil.toDate).addTag("Record"))
    .addFetcher(FetcherMaker.makeScalarFetcher("version", "Version").addTag("Record"))
    .addFetcher(FetcherMaker.makeAPIFetcher("structure/formula", "Molecular Formula").addTag("Chemical"))
    .addFetcher(FetcherMaker.makeAPIFetcher("structure/molfile", "Molfile").addTag("Chemical"))
    .addFetcher(FetcherMaker.makeAPIFetcher("structure/mwt", "Molecular Weight").addTag("Chemical"));

FetcherRegistry.addFetcher(
    FetcherMaker.make("Tags", function (simpleSub) {
        return simpleSub.fetch("tags!(term)!distinct()!sort()!join(|)").andThen(function (n) {
            return n.replace(/%7C/g, "|");
        });
    }).addTag("Record")
);


FetcherRegistry.addFetcher(
    FetcherMaker.make("Structural Modifications", function (simpleSub) {
        return simpleSub.fetch("protein/subunits").andThen(function (subs) {

            return simpleSub.fetch("modifications/structuralModifications").andThen(function (n) {
                return _.chain(n)
                    .map(function (sm) {
                        var type = sm.structuralModificationType;
                        var ext = sm.extent;
                        var mfrag = sm.molecularFragment;
                        var mfragUUID = "";
                        var mfragApprovalID = "";
                        var mfragName = "";
                        var residue = sm.residueModified;
                        var aasites = "";

                        if (mfrag) {
                            mfragUUID = mfrag.refuuid;
                            mfragApprovalID = mfrag.approvalID;
                            mfragName = mfrag.refPname;
                        }
                        if (sm.sites) {
                            aasites = _.chain(sm.sites)
                                .map(function (s) {
                                    var sunit = _.chain(subs)
                                        .find(function (sq) {
                                            return sq.subunitIndex === s.subunitIndex;
                                        })
                                        .value();
                                    var aa = sunit.sequence[s.residueIndex - 1];
                                    return aa;
                                    //s.subunitIndex + "_" + s.residueIndex;
                                })
                                .uniq()
                                .value()
                                .join(";");
                        }
                        return [type, ext, residue, mfragUUID, mfragApprovalID, mfragName, aasites].join("~");
                    })
                    .value()
                    .join("|");
            });
        });
    }).addTag("Protein")
);



FetcherRegistry.addFetcher(
    FetcherMaker.make("Equivalance Factor", function (simpleSub) {

        return simpleSub.fetch("structure/mwt").andThen(function (mwt) {

            return simpleSub.fetch("relationships")
                .andThen(function (r) {
                    var amuuid = _.chain(r)
                        .filter({ type: "ACTIVE MOIETY" })
                        .map(function (ro) {
                            return ro.relatedSubstance.refuuid;
                        })
                        .value()[0];
                    return SubstanceFinder.get(amuuid)
                        .andThen(function (amsub) {
                            return amsub.fetch("structure/mwt").andThen(function (mwt2) {
                                return mwt2 / mwt;
                            });
                        });
                });
        });
    }).addTag("Chemical")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Latin Binomial", function (simpleSub) {
        return simpleSub.fetch("structurallyDiverse!$select(organismGenus,organismSpecies)!join(%20)").andThen(function (n) {
            return n.replace(/%20/g, " ");
        });
    }).addTag("Structurally Diverse")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Author", function (simpleSub) {
        return simpleSub.fetch("structurallyDiverse/organismAuthor");
    }).addTag("Structurally Diverse")
);


FetcherRegistry.addFetcher(
    FetcherMaker.make("Part", function (simpleSub) {
        return simpleSub.fetch("structurallyDiverse/part!(term)!join(|)").andThen(function (n) {
            return n.replace(/%7C/g, "|");
        });
    }).addTag("Structurally Diverse")
);



FetcherRegistry.addFetcher(
    FetcherMaker.make("Stereo Type", function (simpleSub) {
        return simpleSub.fetch("structure/stereoChemistry");
    }).addTag("Chemical")
);

FetcherRegistry.addFetcher(
    FetcherMaker.make("Record URL", function (simpleSub) {
        return JPromise.ofScalar(GlobalSettings.getHomeURL() + "substance/" + simpleSub.uuid);
    }).addTag("Record")
);


//If these names are directly registered
FetcherRegistry.addFetcher(
    FetcherMaker.make("Bracket Terms", function (simpleSub) {
        return simpleSub.fetch("names!(name)").andThen(function (n) {
            return _.chain(n)
                .filter(function (n1) {
                    return n1.match(/\[.*\]/g);
                })
                .value().join("|");
        });
    }).addTag("Substance")
);


//*******************
//CV helper (TODO:move to main library)
//*******************


var CVHelper = {
    getTermList: function (domain) {
        return JPromise.of(function (cb) {
            GGlob.CVFinder.searchByDomain(domain).andThen(function (r) {
                return _.map(r.content[0].terms, function (o) {
                    return o.value;
                });
            }).get(cb);
        });
    }

};



//********************************
//Scripts
//********************************

Script.builder().mix({ name: "Add Name", description: "Adds a name to a substance record" })
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the substance record", required: true
    })
    .addArgument({
        "key": "pt", name: "PT", description: "Preferred Term of the record (used for validation)", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        var rec = resp.content[0];
                        var uuid = rec.uuid;
                        var pt = rec._name;
                        if (uuid !== cargs.args.uuid.getValue()) {
                            return { valid: false, message: "The PT and UUID do not point to the same record" };
                        } else if (val !== pt) {
                            return { valid: false, message: "The PT for this record does not match the one provided" };
                        }
                        return { valid: true };
                    } else {
                        return { valid: false, message: "Could not find record with that PT" };
                    }
                });
        }
    })
    .addArgument({
        "key": "bdnum", name: "BDNUM", description: "BDNUM of the record (used for validation)", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        var rec = resp.content[0];
                        var uuid = rec.uuid;
                        if (uuid !== cargs.args.uuid.getValue()) {
                            return { valid: false, message: "The BDNUM " + val + " and UUID do not point to the same record (" + uuid + " vs " + cargs.args.uuid.getValue() + ")" };
                        }
                        return { valid: true };
                    } else {
                        return { valid: false, message: "Could not find record with that BDNUM" };
                    }
                });
        }
    })
    .addArgument({
        "key": "name", name: "NAME", description: "Name text of the new name", required: true,
        "validator": function (val) {
            return GGlob.SubstanceFinder.searchByExactName(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        return { valid: false, message: "That name already exists for record:" + resp.content[0]._name + ":" + resp.content[0].uuid };
                    } else {
                        return { valid: true };
                    }
                });
        }
    })


    .addArgument({
        "key": "nameType",
        name: "NAME TYPE",
        description: "Name text of the new name",
        defaultValue: "cn",
        required: false,
        type: "cv",
        opPromise: CVHelper.getTermList("NAME_TYPE")
    })
    .addArgument({
        "key": "public", name: "PD", description: "Public Domain status of the name (sets access for reference as well)", defaultValue: false, required: false
    })
    .addArgument({
        "key": "referenceType", name: "REFERENCE TYPE", description: "Type of reference", defaultValue: "SYSTEM", required: false,
        type: "cv",
        opPromise: CVHelper.getTermList("DOCUMENT_TYPE")
    })

    .addArgument({
        "key": "referenceCitation", name: "REFERENCE CITATION", description: "Citation text for reference", required: true
    })
    .addArgument({
        "key": "referenceUrl", name: "REFERENCE URL", description: "URL for the reference", required: false
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Added Name", description: "Text for the record change", required: false
    })
    .setExecutor(function (args) {
        var uuid = args.uuid.getValue();
        var name = args.name.getValue();
        var nameType = args.nameType.getValue();
        var public = args.public.getValue();
        var referenceType = args.referenceType.getValue();
        var referenceCitation = args.referenceCitation.getValue();
        var referenceUrl = args.referenceUrl.getValue();


        var reference = Reference.builder().mix({ citation: referenceCitation, docType: referenceType });
        if (referenceUrl && referenceUrl.length > 0) {
            reference = reference.setUrl(referenceUrl);
        }

        if ((public + "").toUpperCase() === "TRUE" || public === true || (public + "").toUpperCase() === "Y" || (public + "").toUpperCase() === "YES") {
            console.log('perceived public name');
            reference.setPublic(true);
            reference.setPublicDomain(true);
            public = true;
        } else {
            console.log('perceived NON public name');
            reference.setPublic(false);
            reference.setPublicDomain(false);
            public = false;
        }

        var name = Name.builder().setName(name)
            .setType(nameType)
            .setPublic(public)
            .addReference(reference);
        console.log('name: ' + JSON.stringify(name));
        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                return s.patch()
                    .addData(name)
                    .add("/changeReason", args.changeReason.getValue())
                    .apply()
                    .andThen(_.identity);
            });
    })
    .useFor(function (s) {
        Scripts.addScript(s);
    });




Script.builder().mix({ name: "Add Code", description: "Adds a code to a substance record" })
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the substance record", required: true
    })
    .addArgument({
        "key": "code", name: "CODE", description: "Code text of the new code", required: true
    })
    .addArgument({
        "key": "codeSystem", name: "CODE SYSTEM", description: "Code system of the new code", required: true
    })
    .addArgument({
        "key": "codeType", name: "CODE TYPE", description: "Code type of code. For instance, whether it's a primary code", defaultValue: "PRIMARY", required: false
    })
    .addArgument({
        "key": "comments", name: "CODE TEXT", description: "Text for code", required: false
    })
    .addArgument({
        "key": "url", name: "CODE URL", description: "URL to evaluate this code (this is distinct from the reference URL)", required: false
    })
    .addArgument({
        "key": "public", name: "PD", description: "Public Domain status of the code (sets access for reference as well)", defaultValue: false, required: false
    })
    .addArgument({
        "key": "referenceType", name: "REFERENCE TYPE", description: "Type of reference", defaultValue: "SYSTEM", required: false
    })
    .addArgument({
        "key": "referenceCitation", name: "REFERENCE CITATION", description: "Citation text for reference", required: true
    })
    .addArgument({
        "key": "referenceUrl", name: "REFERENCE URL", description: "URL for the reference", required: false
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Added Code", description: "Text for the record change", required: false
    })
    .setExecutor(function (args) {
        var uuid = args.uuid.getValue();
        var code = args.code.getValue();
        var codeType = args.codeType.getValue();
        var codeSystem = args.codeSystem.getValue();
        var codeComments = args.comments.getValue();
        var url = args.url.getValue();
        var public = args.public.getValue();
        var referenceType = args.referenceType.getValue();
        var referenceCitation = args.referenceCitation.getValue();
        var referenceUrl = args.referenceUrl.getValue();

        var reference = Reference.builder().mix({ citation: referenceCitation, docType: referenceType });
        if (referenceUrl && referenceUrl.length > 0) {
            reference = reference.setUrl(referenceUrl);
        }
        if (public && public === "true" || public === true || public === "Y") {
            reference.setPublic(true);
            reference.setPublicDomain(true);
        } else {
            reference.setPublic(false);
            reference.setPublicDomain(false);
        }

        var code = Code.builder().setCode(code)
            .setType(codeType)
            .setCodeSystem(codeSystem)
            .setCodeComments(codeComments)
            .setPublic(public)
            .addReference(reference);

        if (url) {
            code.setUrl(url);
        }
        if (codeComments) {
            code.setCodeComments(codeComments);
        }

        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                return s.patch().addData(code)
                    .add("/changeReason", args.changeReason.getValue())
                    .apply()
                    .andThen(_.identity);
            });
    })
    .useFor(Scripts.addScript);


//Add relationship by MAM 14 June 2017
Script.builder().mix({ name: "Add Relationship", description: "Adds a relationship to a substance record" })
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the (primary) substance record", required: true
    })
    .addArgument({
        "key": "pt", name: "PT", description: "Preferred Term of the primary record (used for validation)", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        var rec = resp.content[0];
                        var uuid = rec.uuid;
                        var pt = rec._name;
                        if (uuid !== cargs.args.uuid.getValue()) {
                            return { valid: false, message: "The PT and UUID (1) do not point to the same record" };
                        } else if (val !== pt) {
                            return { valid: false, message: "The PT for the first record does not match the one provided" };
                        }
                        return { valid: true };
                    } else {
                        return { valid: false, message: "Could not find record with the first PT" };
                    }
                });
        }
    })
    .addArgument({
        "key": "uuid2", name: "UUID2", description: "UUID of the (secondary) substance record", required: true
    })
    .addArgument({
        "key": "pt2", name: "PT2", description: "Preferred Term of the secondary record (used for validation)", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        var rec = resp.content[0];
                        var uuid = rec.uuid;
                        var pt = rec._name;
                        if (uuid !== cargs.args.uuid2.getValue()) {
                            return { valid: false, message: "The PT and UUID (2) do not point to the same record" };
                        } else if (val !== pt) {
                            return { valid: false, message: "The PT for the second record does not match the one provided" };
                        }
                        return { valid: true };
                    } else {
                        return { valid: false, message: "Could not find record with the second PT" };
                    }
                });
        }
    })
    .addArgument({
        "key": "relationshiptype", name: "RELATIONSHIP TYPE", description: "Type of the new relationship",
        "type": "cv", required: true, opPromise: CVHelper.getTermList("RELATIONSHIP_TYPE")
    })
    .addArgument({
        "key": "referenceType", name: "REFERENCE TYPE", description: "Type of reference", defaultValue: "SYSTEM", required: false
    })
    .addArgument({
        "key": "referenceCitation", name: "REFERENCE CITATION", description: "Citation text for reference", required: false
    })
    .addArgument({
        "key": "referenceUrl", name: "REFERENCE URL", description: "URL for the reference", required: false
    })
    .addArgument({
        "key": "referenceTags", name: "REFERENCE TAGS", description: "pipe-delimited set of tags for the reference", required: false
    })
    .addArgument({
        "key": "public", name: "PD", description: "Public Domain status of the relationship (sets access for reference as well)", defaultValue: false, required: false
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Added Code", description: "Text for the record change", required: false
    })
    .setExecutor(function (args) {
        var uuid = args.uuid.getValue();
        var uuid2 = args.uuid2.getValue();
        var relationshiptype = args.relationshiptype.getValue();
        var public = args.public.getValue();
        var referenceType = args.referenceType.getValue();
        var referenceCitation = args.referenceCitation.getValue();
        var referenceUrl = args.referenceUrl.getValue();
        var referenceTags = args.referenceTags.getValue();

        var reference = null;
        if (referenceType != null && referenceCitation != null) {
            //alert('Creating reference with 
            reference = Reference.builder().mix({ citation: referenceCitation, docType: referenceType });
            if (referenceUrl && referenceUrl.length > 0) {
                reference = reference.setUrl(referenceUrl);
            }
            if (public && public === "true" || public === true || public === "Y") {
                reference.setPublic(true);
                reference.setPublicDomain(true);
            } else {
                reference.setPublic(false);
                reference.setPublicDomain(false);
            }
            if (referenceTags != null && referenceTags.length > 0) {
                var tags = referenceTags.split("|");
                var tagSet = [];
                _.forEach(tags, function (tag) {
                    tagSet.push(tag); //test!
                });
                reference.tags = tagSet;
            }
        }


        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                return SubstanceFinder.get(uuid2)
                    .andThen(function (s2) {
                        //alert('Retrieved substances "' + s._name + '" and "' + s2._name + '"');
                        //construct the relationship object
                        var relationship = Relationship.builder()
                            .setRelatedSubstance(s2) //make sure this works!
                            .setType(relationshiptype);
                        if (reference)
                            relationship.addReference(reference);
                        else
                            alert('reference for this relationship was null');

                        return s.patch().addData(relationship)
                            .add("/changeReason", args.changeReason.getValue())
                            .apply()
                            .andThen(_.identity);
                    });
            });
    })
    .useFor(Scripts.addScript);

function dumpObject(obj) {
    var resp = Array();
    for (prop in obj) {
        resp.push(prop + ' = ' + obj[prop]);
    }
}

//add code via substance name MAM 15 June 2017
Script.builder().mix({ name: "Add Code by Name", description: "Adds a code to a substance record when no code of that type already exists" })
    .addArgument({
        "key": "pt", name: "PT", description: "PT of the substance record", required: true
    })
    .addArgument({
        "key": "code", name: "CODE", description: "Code text of the new code", required: true
    })
    .addArgument({
        "key": "codeSystem", name: "CODE SYSTEM", description: "Code system of the new code", required: true
    })
    .addArgument({
        "key": "codeType", name: "CODE TYPE", description: "Code type of code. For instance, whether it's a primary code", defaultValue: "PRIMARY", required: false
    })
    .addArgument({
        "key": "comments", name: "CODE TEXT", description: "Text for code", required: false
    })
    .addArgument({
        "key": "url", name: "CODE URL", description: "URL to evaluate this code (this is distinct from the reference URL)", required: false
    })
    .addArgument({
        "key": "public", name: "PD", description: "Public Domain status of the code (sets access for reference as well)",
        defaultValue: false, required: false
    })
    .addArgument({
        "key": "referenceType", name: "REFERENCE TYPE", description: "Type of reference", defaultValue: "SYSTEM", required: false
    })
    .addArgument({
        "key": "referenceCitation", name: "REFERENCE CITATION", description: "Citation text for reference", required: false
    })
    .addArgument({
        "key": "referenceUrl", name: "REFERENCE URL", description: "URL for the reference", required: false
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Added Code", description: "Text for the record change", required: false
    })
    .addArgument({
        "key": "referenceTags", name: "REFERENCE TAGS", description: "pipe-delimited set of tags for the reference", required: false
    })
    .addArgument({
        "key": "allowMultiple", name: "ALLOW MULTIPLES", description: "Allow the entry of multiple codes within the same code system",
        defaultValue: false, required: false
    })
    .setExecutor(function (args) {
        var pt = args.pt.getValue();
        var codeInput = args.code.getValue();
        var codeType = args.codeType.getValue();
        var codeSystem = args.codeSystem.getValue();
        var codeComments = args.comments.getValue();
        var url = args.url.getValue();
        var public = args.public.getValue();
        var referenceType = args.referenceType.getValue();
        var referenceCitation = args.referenceCitation.getValue();
        var referenceUrl = args.referenceUrl.getValue();
        var reference = null;
        var referenceTags = args.referenceTags.getValue();
        var allowMultipleInput = args.allowMultiple.getValue();
        var allowMultiple = false;
        if (allowMultipleInput &&
            (allowMultipleInput === true ||
                allowMultipleInput.toUpperCase() === 'TRUE' || allowMultipleInput.toUpperCase().startsWith('Y'))) {
            allowMultiple = true;
        }
        console.log('allowMultiple: ' + allowMultiple);

        if (referenceType && referenceType.length > 0 && referenceCitation != null
            && referenceCitation.length > 0) {
            reference = Reference.builder().mix({ citation: referenceCitation, docType: referenceType });
            reference = reference.setUrl(referenceUrl);
            if (public && public === "true" || public === true || public === "Y") {
                reference.setPublic(true);
                reference.setPublicDomain(true);
            } else {
                reference.setPublic(false);
                reference.setPublicDomain(false);
            }
            if (referenceTags != null && referenceTags.length > 0) {
                var tags = referenceTags.split("|");
                var tagSet = [];
                _.forEach(tags, function (tag) {
                    tagSet.push(tag); //test!
                });
                reference.tags = tagSet;
            }
        }

        var code = Code.builder()
            .setCode(codeInput)
            .setType(codeType)
            .setCodeSystem(codeSystem)
            .setCodeComments(codeComments)
            .setPublic(public);
        if (reference)
            code.addReference(reference);

        if (url) {
            code.setUrl(url);
        }
        if (codeComments) {
            code.setCodeComments(codeComments);
        }

        //return SubstanceFinder.get(uuid) 
        return GGlob.SubstanceFinder.searchByExactNameOrCode(pt)
            .andThen(function (resp) {

                if (resp.content && resp.content.length >= 1) {
                    var rec = resp.content[0];

                    var substance = GGlob.SubstanceBuilder.fromSimple(rec);
                    console.log('Found a substance with PT: ' + pt);
                    return substance.fetch("codes")
                        .andThen(function (codes) {
                            var valuesOK = true;
                            var valuesError = '';
                            _.forEach(codes, function (cd) {
                                if (cd.codeSystem == codeSystem) {
                                    if (allowMultiple) {
                                        //use the double equal to allow coercion of values
                                        //console.log('	about to compare codes: ' + cd.code + ' and ' + codeInput);
                                        if (cd.code == codeInput) {
                                            console.log(' duplicate code detected');
                                            valuesOK = false;
                                            valuesError = 'This substance already has the code "'
                                                + codeInput + '" for system ' + cd.codeSystem;
                                            return false;
                                        }
                                    }
                                    else {
                                        valuesOK = false;
                                        valuesError = 'This substance already has a code for system '
                                            + cd.codeSystem;
                                        return false;
                                    }
                                    //console.log(cd.code + "\t" + cd.codeSystem);
                                }
                            });
                            if (valuesOK) {
                                console.log('Add Code by Name is going to return patch ');
                                //alert('valuesOK true; valuesError = ' + valuesError + '; going to add code');
                                return rec.patch().addData(code)
                                    .add("/changeReason", args.changeReason.getValue())
                                    .apply()
                                    .andThen(_.identity);
                            } else {
                                console.log('Add Code by Name is going to return message ' + valuesError);
                                return { "message": valuesError, "valid": false };
                            }
                        });
                } else {
                    console.log('resp: ' + JSON.stringify(resp));
                    console.log('Did not locate substance based on ' + pt);
                    //MAM: testing adding full resp to output
                    return { "message": "Did not locate substance based on " + pt, "valid": false, "extra": resp };
                }
            });
    })
    .useFor(Scripts.addScript);

//replace code via substance name MAM 26 June 2017
Script.builder().mix({ name: "Replace Code by Name", description: "Replaces one code with another of the same type for a substance record identified by preferred term" })
    .addArgument({
        "key": "pt", name: "PT", description: "PT of the substance record", required: true
    })
    .addArgument({
        "key": "code", name: "CODE", description: "Code text of the new code", required: true
    })
    .addArgument({
        "key": "codeSystem", name: "CODE SYSTEM", description: "Code system for the old and new codes", required: true
    })
    .addArgument({
        "key": "codeType", name: "CODE TYPE", description: "Code type of code. For instance, primary", defaultValue: "PRIMARY", required: false
    })
    .addArgument({
        "key": "comments", name: "CODE TEXT", description: "Text for new/replacement code", required: false
    })
    .addArgument({
        "key": "url", name: "CODE URL", description: "URL to evaluate this code (this is distinct from the reference URL)", required: false
    })
    .addArgument({
        "key": "public", name: "PD", description: "Public Domain status of the code (sets access for reference as well)", defaultValue: false, required: false
    })
    .addArgument({
        "key": "referenceType", name: "REFERENCE TYPE", description: "Type of reference", defaultValue: "SYSTEM", required: false
    })
    .addArgument({
        "key": "referenceCitation", name: "REFERENCE CITATION", description: "Citation text for reference", required: false
    })
    .addArgument({
        "key": "referenceUrl", name: "REFERENCE URL", description: "URL for the reference", required: false
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Added Code", description: "Text for the record change", required: false
    })
    .addArgument({
        "key": "referenceTags", name: "REFERENCE TAGS", description: "pipe-delimited set of tags for the reference", required: false
    })
    .setExecutor(function (args) {
        var pt = args.pt.getValue();
        var codeValue = args.code.getValue();
        var codeType = args.codeType.getValue();
        var codeSystem = args.codeSystem.getValue();
        var codeComments = args.comments.getValue();
        var url = args.url.getValue();
        var public = args.public.getValue();
        var referenceType = args.referenceType.getValue();
        var referenceCitation = args.referenceCitation.getValue();
        var referenceUrl = args.referenceUrl.getValue();
        var reference = null;
        var referenceTags = args.referenceTags.getValue();

        if (referenceType && referenceType.length > 0 && referenceCitation != null && referenceCitation.length > 0) {
            reference = Reference.builder().mix({ citation: referenceCitation, docType: referenceType });
            reference = reference.setUrl(referenceUrl);
            if (public && public === "true" || public === true || public === "Y") {
                reference.setPublic(true);
                reference.setPublicDomain(true);
            } else {
                reference.setPublic(false);
                reference.setPublicDomain(false);
            }
            if (referenceTags != null && referenceTags.length > 0) {
                var tags = referenceTags.split("|");
                var tagSet = [];
                _.forEach(tags, function (tag) {
                    tagSet.push(tag); //test!
                });
                reference.tags = tagSet;
            }
        }

        var code = Code.builder()
            .setCode(codeValue)
            .setType(codeType)
            .setCodeSystem(codeSystem)
            .setCodeComments(codeComments)
            .setPublic(public);
        if (reference)
            code.addReference(reference);

        if (url) {
            code.setUrl(url);
        }
        if (codeComments) {
            code.setCodeComments(codeComments);
        }

        return GGlob.SubstanceFinder.searchByExactNameOrCode(pt)
            .andThen(function (resp) {
                if (resp.content && resp.content.length >= 1) {
                    var rec = resp.content[0];

                    var substance = GGlob.SubstanceBuilder.fromSimple(rec);
                    console.log('Found a substance with PT: ' + pt);
                    return substance.fetch("codes")
                        .andThen(function (codeCollection) {
                            return substance.fetch("references")
                                .andThen(function (referenceCollection) {
                                    var indexCodeToRemove = -1;
                                    var indexReferenceToRemove = -1;
                                    var indexReferencesToRemove = [];
                                    for (var i = 0; i < codeCollection.length; i++) {
                                        if (codeCollection[i].codeSystem == codeSystem) {
                                            indexCodeToRemove = i;
                                            break;
                                        }
                                    }

                                    for (var i = 0; i < referenceCollection.length; i++) {
                                        if (referenceCollection[i].docType == referenceType) {
                                            indexReferenceToRemove = i;
                                            indexReferencesToRemove.push(i);
                                        }
                                    }
                                    if (indexCodeToRemove > -1 && indexReferenceToRemove > -1) {
                                        console.log('going to remove reference ' +
                                            referenceCollection[indexReferenceToRemove].url);
                                        return rec.patch()
                                            .remove("/codes/" + indexCodeToRemove)
                                            .remove("/references/" + indexReferenceToRemove)
                                            .addData(code)
                                            .add("/changeReason", args.changeReason.getValue())
                                            .apply()
                                            .andThen(_.identity);
                                    } else {
                                        return { "message": "Error locating code to replace", "valid": false };
                                    }
                                })
                        })
                } else {
                    console.log('Did not locate substance based on ' + pt);
                    return { "message": "Did not locate substance based on " + pt, "valid": false };
                }
            });
    })
    .useFor(Scripts.addScript);

//Remove Name
Script.builder().mix({ name: "Remove Name", description: "Removes a name from a substance record" })
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the substance record", required: true
    })
    .addArgument({
        "key": "pt", name: "PT", description: "Preferred Term of the record (used for validation)", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        var rec = resp.content[0];
                        var uuid = rec.uuid;
                        var pt = rec._name;
                        if (uuid !== cargs.args.uuid.getValue()) {
                            return { valid: false, message: "The PT and UUID do not point to the same record" };
                        } else if (val !== pt) {
                            return { valid: false, message: "The PT for this record does not match the one provided" };
                        }
                        return { valid: true };
                    } else {
                        return { valid: false, message: "Could not find record with that PT" };
                    }
                });
        }
    })
    .addArgument({
        "key": "bdnum", name: "BDNUM", description: "BDNUM of the record (used for validation)", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        var rec = resp.content[0];
                        var uuid = rec.uuid;
                        if (uuid !== cargs.args.uuid.getValue()) {
                            return { valid: false, message: "The BDNUM " + val + " and UUID do not point to the same record (" + uuid + " vs " + cargs.args.uuid.getValue() + ")" };
                        }
                        return { valid: true };
                    } else {
                        return { valid: false, message: "Could not find record with that BDNUM" };
                    }
                });
        }
    })
    .addArgument({
        "key": "name", name: "NAME", description: "Name text of the name to delete", required: true,
        "validator": function (val) {
            //todo: change this validator to search by UUID, then look for the name among the record's names
            return GGlob.SubstanceFinder.searchByExactName(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length < 1) {
                        return { valid: false, message: "The name '" + val + "' was not found in the database. " };
                    } else {
                        return { valid: true };
                    }
                });
        }
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Delete Name", description: "Text for the record change", required: false
    })
    .setExecutor(function (args) {
        var uuid = args.uuid.getValue();
        var nameToRemove = args.name.getValue();

        var s0;
        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                s0 = s;
                return s.full();
            })
            .andThen(function (s) {
                var nameIndex = -1;
                for (var i = 0; i < s.names.length; i++) {
                    if (s.names[i].name === nameToRemove) {
                        nameIndex = i;
                        break;
                    }
                }

                if (nameIndex <= -1) {
                    return { valid: false, message: "Unable to locate name to delete: " + nameToRemove }
                }
                return s0.patch()
                    .remove("/names/" + nameIndex, args.changeReason.getValue())
                    .apply()
                    .andThen(function (s0) {
                        return s0;
                    }
														/*_.identity*/);
            });
    })
    .useFor(function (s) {
        Scripts.addScript(s);
    });


//Update the URL for a given code via substance name MAM 6 July 2017
Script.builder().mix({
    name: "Fix Code URLS",
    description: "Replaces the URL associated with a code on a substance record when a code of that type already exists"
})
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the substance record", required: true
    })
    .addArgument({
        "key": "codeSystem", name: "CODE SYSTEM", description: "Code system to modify", required: true, defaultValue: "CAS"
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Fixing Code URLs", description: "Text for the record change", required: false
    })

    .addArgument({
        "key": "urlBase", name: "URL BASE", defaultValue: "Stem for the formation of URLs, with Code to be appended", description: "Text for the record change", required: true
    })

    .setExecutor(function (args) {
        var uuid = args.uuid.getValue();
        var codeSystem = args.codeSystem.getValue();

        var urlBase = args.urlBase.getValue();

        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                //console.log('Starting in first andThen');
                s0 = s;
                if (s)
                    return s.full();
                else
                    return { valid: false, message: 'unexpected error' };
            })

            .andThen(function (s) {
                console.log('Starting in second andThen');
                if (s.valid === false)
                    return s;
                console.log('Looking at codes collection which has ' + s.codes.length);

                var codesToUpdate = [];
                var codeIndicesToUpdate = [];

                _.forEach(s.codes, function (c, i) {
                    if (c.codeSystem === codeSystem) {
                        //replace the URL
                        c.url = urlBase + c.code
                        codesToUpdate.push(c);
                        codeIndicesToUpdate.push(i);
                    }
                });

                var updatePatch = s0.patch()
                /* This code handles multiple items*/
                _.forEach(codesToUpdate, function (c, i) {
                    updatePatch = updatePatch.replace("/codes/" + codeIndicesToUpdate[i], c);
                });
                return updatePatch
                    .add("/changeReason", args.changeReason.getValue())
                    .apply()
                    .andThen(function (arg) {
                        console.log(arg);
                        return arg;
                    });
            })
    })

    .useFor(function (s) {
        Scripts.addScript(s);
    });

//Set object MAM 5 July 2017
Script.builder().mix({ name: "Set Object JSON", description: "Replace an entire record based on JSON read in" })
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the substance record", required: true
    })
    .addArgument({
        "key": "json", name: "JSON STRING", description: "JSON version of record to replace", required: true
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", description: "Text for the record change", required: false
    })
    .setExecutor(function (args) {
        var uuid = args.uuid.getValue();
        var jsonString = args.json.getValue();

        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                var updatePatch = s.patch()
                updatePatch = updatePatch.replace("", JSON.parse(jsonString));

                return updatePatch
                    .add("/changeReason", args.changeReason.getValue())
                    .apply()
                    .andThen(function (arg) {
                        if (typeof (arg) == 'string')
                            console.log(arg);
                        else
                            console.log(JSON.stringify(arg));
                        return arg;
                    });
            })
    })
    .useFor(function (s) {
        Scripts.addScript(s);
    });

//Update the visibility of a given code via UUID MAM 14 October 2017
Script.builder().mix({ name: "Set Code Access", description: "Sets the permission on a code for a given substance record" })
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the substance record", required: true
    })
    .addArgument({
        "key": "codeSystem", name: "CODE SYSTEM", description: "Code system to modify", required: true, defaultValue: "CAS"
    })
    .addArgument({
        "key": "newAccess", name: "ACCESS", defaultValue: "protected", description: "Text for the access value of the code",
        required: true
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Changing Code protection", description: "Text for the record change", required: false
    })

    .setExecutor(function (args) {

        var ACCESS_NONE = '[NONE]';

        var uuid = args.uuid.getValue();

        var codeSystem = args.codeSystem.getValue();

        var access = args.newAccess.getValue();


        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                s0 = s;
                if (s)
                    return s.full();
                else
                    return { valid: false, message: 'unexpected error' };
            })
            .andThen(function (s) {
                console.log('Starting in second andThen');
                if (s.valid === false)
                    return s;
                console.log('Looking at codes collection which has ' + s.codes.length);

                var codesToUpdate = [];
                var codeIndicesToUpdate = [];

                _.forEach(s.codes, function (c, i) {
                    if (c.codeSystem === codeSystem) {
                        //replace the access
                        if (!(c.access && typeof (c.access) === 'object')) {
                            console.log('creating access array');
                            c.access = [];
                        }
                        console.log('Appending access: ' + access);
                        if (access === ACCESS_NONE) {
                            c.access = [];
                        } else {
                            c.access.push(access);
                        }
                        codesToUpdate.push(c);
                        codeIndicesToUpdate.push(i);
                    }
                });

                var updatePatch = s0.patch()
                /* This code handles multiple items*/
                _.forEach(codesToUpdate, function (c, i) {
                    updatePatch = updatePatch.replace("/codes/" + codeIndicesToUpdate[i], c);
                });
                return updatePatch
                    .add("/changeReason", args.changeReason.getValue())
                    .apply()
                    .andThen(function (arg) {
                        console.log(arg);
                        return arg;
                    });
            })
    })
    .useFor(function (s) {
        Scripts.addScript(s);
    });
//new material 29 September 2017 MAM
Script.builder().mix({ name: "Create Substance", description: "Creates a brand new substance record" })
    .addArgument({
        "key": "pt", name: "PT", description: "Preferred Term of the new substance", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        return { valid: false, message: "The PT for this record already exists" };
                    } else {
                        return { valid: true };
                    }
                });
        }
    })
    .addArgument({
        "key": "ptLang", name: "PT LANGUAGE", description: "2-letter language abbreviation for Preferred Term",
        required: true, defaultValue: "en"
        //todo: add validator to make sure value corresponds to one of the members of the list of known languages
    })
    .addArgument({
        "key": "ptNameType", name: "PT NAME TYPE", description: "2/3-letter name type (e.g., cn, of) for Preferred Term",
        required: true, defaultValue: "cn"
        //todo: add validator to make sure value corresponds to one of the members of the list of known types
    })
    .addArgument({
        "key": "SubstanceClass", name: "SUBSTANCE CLASS", description: "Category", required: true, defaultValue: "chemical"
        //todo: add validator to make sure value corresponds to one of the members of the list of known classes
    })
    .addArgument({
        "key": "smiles", name: "SMILES", description: "Structure as SMILES",
        required: false
    })
    .addArgument({
        "key": "molfile", name: "MOLFILE", description: "Structure as molfile",
        required: false
    })
    .addArgument({
        "key": "referenceType", name: "REFERENCE TYPE", description: "Type of reference", defaultValue: "SYSTEM", required: false
    })
    .addArgument({
        "key": "referenceCitation", name: "REFERENCE CITATION", description: "Citation text for reference", required: true
    })
    .addArgument({
        "key": "referenceUrl", name: "REFERENCE URL", description: "URL for the reference", required: false
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Creating new substance", description: "Text for the record change",
        required: false
    })
    .addArgument({
        "key": "public", name: "PD", description: "Public Domain status of the code (sets access for reference as well)", defaultValue: false, required: false
    })
    .setExecutor(function (args) {
        var pt = args.pt.getValue();
        var substanceClass = args.SubstanceClass.getValue();

        var public = args.public.getValue();
        var referenceType = args.referenceType.getValue();
        var referenceCitation = args.referenceCitation.getValue();
        var referenceUrl = args.referenceUrl.getValue();
        var smiles = args.smiles.getValue();
        var molfileText = args.molfile.getValue();
        var nameType = args.ptNameType.getValue();
        console.log('nameType: ' + nameType);
        var nameLang = args.ptLang.getValue();

        var refuuid = GSRSAPI.builder().UUID.randomUUID();
        var reference = Reference.builder().mix({ citation: referenceCitation, docType: referenceType });
        if (referenceUrl && referenceUrl.length > 0) {
            reference = reference.setUrl(referenceUrl);
        }
        if ((public + "").toUpperCase() === "TRUE" || public === true || (public + "").toUpperCase() === "Y" || (public + "").toUpperCase() === "YES") {
            reference.setPublic(true);
            reference.setPublicDomain(true);
        } else {
            reference.setPublic(false);
            reference.setPublicDomain(false);
        }
        reference.uuid = refuuid;

        var langs = [];
        langs.push(nameLang);
        var name = Name.builder().setName(pt)
            .setType(nameType)
            .setPublic(public)
            .setPreferred(true)
            .setLanguages(langs)
            .addReference(reference);

        var simpleSub = {
            substanceClass: substanceClass,
            access: ["protected"],
            names: [],
            references: []
        };
        simpleSub.names.push(name);
        simpleSub.references.push(reference);

        if ((smiles && smiles.length > 0) || (molfileText && molfileText.length > 0)) {
            console.log('Processing SMILES/molfile')
            var structure = {};
            structure.smiles = smiles;
            if (molfileText && molfileText.length > 0) {
                console.log('molfileText not null.');
                structure.molfile = molfileText;
            } else {
                console.log('molfileText null.');
                structure.molfile = smiles;
            }
            structure.references = [];
            structure.references.push(refuuid);
            simpleSub.structure = structure;
        }

        var sub = SubstanceBuilder.fromSimple(simpleSub);

        return sub.patch()
            //.add("/changeReason",args.changeReason.getValue())
            //.validate()
            .apply()
            .andThen(function (resp) {
                if (typeof (resp) == 'object')
                    console.log(JSON.stringify(resp));
                else
                    console.log(resp);
                return resp;//{"message":"success", "valid":true, "extra":resp};
            });

    })
    .useFor(function (s) {
        Scripts.addScript(s);
    });


//Touch Record - retrieve a record and save again without making any changes to trigger update processing
Script.builder().mix({ name: "Touch Record", description: "Retrieve a substance record and save again with no futher changes" })
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the substance record", required: true
    })

    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Trigger update processing", description: "Text for the record change", required: false
    })
    .setExecutor(function (args) {
        var uuid = args.uuid.getValue();

        var s0;
        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                console.log('Processing ' + s.uuid);
                return s.patch()
                    //.addData(name)
                    .add("/changeReason", args.changeReason.getValue())
                    .apply()
                    .andThen(_.identity);
            });
    })
    .useFor(function (s) {
        Scripts.addScript(s);
    });


//Replace one name with another
Script.builder().mix({ name: "Replace Name", description: "Locates an existing name within a substance record and replaces it with a new name" })
    .addArgument({
        "key": "uuid", name: "UUID", description: "UUID of the substance record", required: true
    })

    .addArgument({
        "key": "pt", name: "PT", description: "Preferred Term of the record (used for validation)", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        var rec = resp.content[0];
                        var uuid = rec.uuid;
                        var pt = rec._name;
                        if (uuid !== cargs.args.uuid.getValue()) {
                            return { valid: false, message: "The PT and UUID do not point to the same record" };
                        } else if (val !== pt) {
                            return { valid: false, message: "The PT for this record does not match the one provided" };
                        }
                        return { valid: true };
                    } else {
                        return { valid: false, message: "Could not find record with that PT" };
                    }
                });
        }
    })
    .addArgument({
        "key": "bdnum", name: "BDNUM", description: "BDNUM of the record (used for validation)", required: true,
        "validator": function (val, cargs) {
            return GGlob.SubstanceFinder.searchByExactNameOrCode(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length >= 1) {
                        var rec = resp.content[0];
                        var uuid = rec.uuid;
                        if (uuid !== cargs.args.uuid.getValue()) {
                            return { valid: false, message: "The BDNUM " + val + " and UUID do not point to the same record (" + uuid + " vs " + cargs.args.uuid.getValue() + ")" };
                        }
                        return { valid: true };
                    } else {
                        return { valid: false, message: "Could not find record with that BDNUM" };
                    }
                });
        }
    })
    .addArgument({
        "key": "currentName", name: "CURRENT NAME", description: "Name text of the name to replace", required: true,
        "validator": function (val) {
            //todo: change this validator to search by UUID, then look for the name among the record's names
            return GGlob.SubstanceFinder.searchByExactName(val)
                .andThen(function (resp) {
                    if (resp.content && resp.content.length < 1) {
                        return { valid: false, message: "The name '" + val + "' was not found in the database. " };
                    } else {
                        return { valid: true };
                    }
                });
        }
    })
    .addArgument({
        "key": "newName", name: "NEW NAME", description: "Text for the record change", required: true
    })
    .addArgument({
        "key": "changeReason", name: "CHANGE REASON", defaultValue: "Replace Name", description: "Text for the record change", required: false
    })
    .setExecutor(function (args) {
        var uuid = args.uuid.getValue();
        var nameToReplace = args.currentName.getValue();
        var newName = args.newName.getValue();

        var name = null;

        var s0;
        return SubstanceFinder.get(uuid)
            .andThen(function (s) {
                s0 = s;
                return s.full();
            })
            .andThen(function (s) {
                var nameIndex = -1;
                for (var i = 0; i < s.names.length; i++) {
                    if (s.names[i].name === nameToReplace) {
                        nameIndex = i;
                        name = Name.builder().setName(newName)
                            .setType(s.names[i].type)
                            .setLanguages(s.names[i].languages)
                            .setDomains(s.names[i].domains)
                            .setNameOrgs(s.names[i].nameOrgs);
                        console.log('Built name with value ' + newName + '; type: ' + s.names[i].type
                            + '; domains: ' + s.names[i].domains);
                        name.public = s.names[i].public;
                        name.references = s.names[i].references;
                        name.access = s.names[i].access;
                        console.log('	applied additional properties such as public ' + name.public);
                        break;
                    }
                }

                if (nameIndex <= -1) {
                    return { valid: false, message: "Unable to locate name to replace: " + nameToReplace }
                }
                return s0.patch()
                    .replace("/names/" + nameIndex, name)
                    .add("/changeReason", args.changeReason.getValue())
                    .apply()
                    .andThen(_.identity);
            });
    })
    .useFor(function (s) {
        Scripts.addScript(s);
    });


window.external.Proceed('script loaded');
