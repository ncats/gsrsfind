﻿var GSRSAPI = {
    builder: function () {
        var g_api = {};
        g_api.GlobalSettings = {
            _url: "https://ginas.ncats.nih.gov/ginas/app/api/v1/",
            _status: "OK", //set to ERROR when there's a problem
            _errorMessage: "",
            getBaseURL: function () {
                return g_api.GlobalSettings._url;
            },
            setBaseURL: function (url) {
                g_api.GlobalSettings._url = url;
                return g_api.GlobalSettings;
            },
            getHomeURL: function () {
                return g_api.GlobalSettings.getBaseURL().replace(/api.v1.*/g, "");
            },
            httpType: function () {
                return "jsonp"; //get only
                //return "json"; //CORS needed, updates possible 
            },
            authToken: null,
            authenticate: function (req) {
                req.headers = {};
                //push token header for now
                var tok = g_api.GlobalSettings.authToken;
                if (tok !== null) {
                    req.headers["auth-token"] = tok;
                }
            },
            getStatus: function () {
                return GlobalSettings._status;
            },
            setStatus: function (newStatus) {
                GlobalSettings._status = newStatus;
                console.log('Setting status to ' + newStatus);
            },
            getErrorMessage: function () {
                return GlobalSettings._errorMessage;
            }
        };

        //TODO: should be its own service
        g_api.httpProcess = function (req) {
            return g_api.JPromise.of(function (cb) {
                var b = req._b;
                if (b) {
                    b = JSON.stringify(b);
                } else {
                    b = req._q;
                }
                if (req._url.match(/.*[?]/)) {
                    req._url = req._url + "&cache=" + g_api.UUID.randomUUID();
                } else {
                    req._url = req._url + "?cache=" + g_api.UUID.randomUUID();
                }
                g_api.GlobalSettings.authenticate(req);

                console.log("called:" + req._url);
                $.ajax({
                    url: req._url,
                    jsonp: "callback",
                    dataType: GlobalSettings.httpType(),
                    contentType: 'application/json',
                    type: req._method,
                    data: b,
                    beforeSend: function (request) {
                        console.log('beforeSend at ' + _.now());

                        if (req.headers) {
                            _.forEach(_.keys(req.headers), function (k) {
                                request.setRequestHeader(k, req.headers[k]);
                            });
                        }
                    },
                    isJson: function (str) {
                        try {
                            JSON.parse(str);
                        }
                        catch (e) {
                            console.log('	error in isJson: ' + e);
                            return false;
                        }
                        return true;
                    },
                    success: function (response) {
                        console.log('ajax call success ');
                        console.log('	at ' + _.now());
                        cb(response);
                    },
                    error: function (response, error, t) {
                        var msg = 'Error from server. response: '
                            + JSON.stringify(response) + '; error: '
                            + JSON.stringify(error) + '\t' + '; t:' + t;
                        console.log(msg);


                        if ((response.status >= 400 && response.status <= 600) || (response.status == 0)) {
                            if (response.status == 500 && response.responseText === "java.lang.reflect.InvocationTargetException"
                                && response.readyState == 4) {
                                //not necessarily an error.
                                // This message occurs when we attempt to retrieve a section from a substance 
                                // that does not have that type of section (e.g., a protein does not have a molfile)
                                console.log('500 error');


                            } else {
                                GlobalSettings.setStatus("ERROR " + response.status);
                            }
                        }
                        GlobalSettings._errorMessage = error;
                        //figure out the message that will be displayed to the user in Excel
                        if (response.responseText) {
                            console.log('Noting error. ');
                            GlobalSettings._errorMessage = response.responseText;
                            console.log('	just set errorMessage');
                            var retMsg = { valid: false };

                            console.log('	initialized retMsg');
                            //detect a complex, nested error message
                            if (typeof (response.responseText) == 'string' && this.isJson(response.responseText)) {
                                var responseRestored = JSON.parse(response.responseText);
                                console.log(' parsed JSON');
                                if (responseRestored.validationMessages && responseRestored.validationMessages.length > 0) {
                                    console.log('	error msg: ' + responseRestored.validationMessages[0].message);
                                    retMsg.message = responseRestored.validationMessages[0].message;
                                    GlobalSettings._errorMessage = responseRestored.validationMessages[0].message;
                                    if (responseRestored.validationMessages.length > 1) {
                                        retMsg.message = retMsg.message + ' + more';
                                        GlobalSettings._errorMessage = GlobalSettings._errorMessage + '...';
                                    }

                                }
                                else if (responseRestored.message) {
                                    retMsg.message = responseRestored.message;
                                    GlobalSettings._errorMessage = responseRestored.message;
                                }
                                else retMsg.message = "unparsed error";
                            }
                            else if (typeof (response.responseText) == 'object' && response.responseText.message) {
                                console.log(' object');
                                retMsg.message = response.responseText.message;
                                if (response.status == 502) {
                                    console.log('502; proxy error');
                                    retMsg.message = 'proxy error on server. Please report this to your administrator!';
                                }


                            }
                            else {
                                console.log(' simple message. response.status: ' + response.status);
                                //simple message
                                retMsg.message = response.responseText;
                                if (response.status == 502) {
                                    console.log('502; proxy error');
                                    retMsg.message = 'proxy error on server. Please report this to your administrator!';
                                }
                            }
                            console.log(' about to invoke cb');
                            cb(retMsg);

                        }
                        else {
                            console.log('Error missing');
                            cb(response);
                        }
                    }
                });
            });
        };

        //Returns an object which will call
        //the supplied callback after {{total}}
        //number of calls to {{decrement}}
        g_api.getListener = function (total, cb) {
            return {
                total: total,
                current: 0,
                callback: cb,
                decrement: function () {
                    this.current++;
                    if (this.current >= this.total) {
                        this.callback();
                    }
                }
            };
        }

        g_api.JPromise = {
            ofScalar: function (s) {
                return g_api.JPromise.of(function (cb) {
                    cb(s);
                });
            },
            of: function (calc) {
                var ret = {
                    get: function (cb) {
                        calc(cb);
                    },
                    andThen: function (lam) {
                        return g_api.JPromise.of(function (cb) {
                            ret.get(function (orig) {
                                var ret = lam(orig);
                                if (ret && ret._promise) {
                                    ret.get(cb);
                                } else if (typeof ret === "undefined") {
                                    cb(orig);
                                } else {
                                    cb(ret);
                                }
                            });
                        });
                    },
                    _promise: true
                };
                return ret;
            },

            join: function (listo) {
                var list = [];
                if (arguments.length > 1) {
                    list = arguments;
                } else {
                    list = listo;
                }
                return g_api.JPromise.of(function (cb) {
                    var toRet = {};
                    var retFun = function () {
                        var retList = [];
                        for (var j = 0; j < list.length; j++) {
                            retList.push(toRet[j]);
                        }
                        return retList;
                    };
                    var listener = g_api.getListener(list.length, function () {
                        cb(retFun());
                    });
                    var proc = function (pFetch, key) {
                        pFetch.get(function (ret) {
                            toRet[key] = ret;
                            listener.decrement();
                        });
                    };
                    for (var i = 0; i < list.length; i++) {
                        var pFetch = list[i];
                        proc(pFetch, i);
                    }
                });
            }
        };

        g_api.gUtil = {
            empty: {},

            deepIterate: function (o, path, cb) {
                if (_.isFunction(o)) {
                    return g_api.gUtil.empty;
                } else if (_.isObject(o)) {
                    if (_.isArray(o)) {
                        var ks = _.keys(o);
                        _.forEach(ks, function (k) {
                            g_api.gUtil.deepIterate(o[k], path + "[" + k + "]", cb);
                        });
                    } else {
                        var ks = _.keys(o);
                        _.forEach(ks, function (k) {
                            g_api.gUtil.deepIterate(o[k], path + "/" + k, cb);
                        });
                    }
                } else {
                    cb(path, o);
                }
            },
            forEachDeep: function (o, path, cb) {
                var node = function (path, key, value, parent) {
                    return {
                        path: path,
                        key: key,
                        value: value,
                        parent: parent
                    };
                };
                if (_.isFunction(o)) {
                    return g_api.gUtil.empty;
                } else if (_.isObject(o)) {
                    if (_.isArray(o)) {
                        var ks = _.keys(o);
                        var mod = false;
                        _.forEach(ks, function (k) {
                            var rep = cb(node(path, k, o[k], o));
                            if (rep == g_api.gUtil.empty) {
                                o[k] = g_api.gUtil.empty;
                                mod = true;
                            } else {
                                if (typeof rep !== "undefined") {
                                    o[k] = rep;
                                }
                                g_api.gUtil.forEachDeep(o[k], path + "/" + k, cb);
                            }
                        });
                        if (mod) {
                            var newArray = _.filter(o, function (e) {
                                if (e == g_api.gUtil.empty)
                                    return false;
                                return true
                            });
                            o.splice(0, o.length);
                            _.forEach(newArray, function (a) {
                                o.push(a);
                            });
                        }
                    } else {
                        var ks = _.keys(o);
                        _.forEach(ks, function (k) {
                            var rep = cb(node(path, k, o[k], o));
                            if (rep === gUtil.empty) {
                                delete o[k];
                            } else {
                                if (typeof rep !== "undefined") {
                                    o[k] = rep;
                                }
                                g_api.gUtil.forEachDeep(o[k], path + "/" + k, cb);
                            }
                        });
                    }
                }
            },
            removeDeep: function (o, test) {
                g_api.gUtil.forEachDeep(o, "", function (node) {
                    if (test(node)) {
                        return gUtil.empty;
                    }
                });
            },
            removeKeysLike: function (o, regex) {
                g_api.gUtil.removeDeep(o, function (node) {
                    return node.key.match(regex);
                });
            },
            toDate: function (d) {
                return new Date(d);
            }
        };

        g_api.ResourceFinder = {
            builder: function () {
                var finder = {};
                finder.resource = function (resource) {
                    finder.resource = resource;
                    return finder;
                };
                finder.searcher = function () {
                    return g_api.SearchRequest.builder()
                        .resource(finder.resource);
                };
                finder.search = function (q) {
                    return finder.searcher()
                        .query(q)
                        .execute();
                };
                finder.get = function (uuid) {
                    alert('starting in finder.get with uuid ' + uuid);
                    var req = g_api.Request.builder()
                        .url(g_api.GlobalSettings.getBaseURL() + finder.resource + "(" + uuid + ")");

                    return g_api.httpProcess(req).andThen(function (sim) {
                        //TODO: make generic
                        return g_api.SubstanceBuilder.fromSimple(sim);
                    });
                };

                finder.extend = function (f) {
                    var nfinder = f(finder);
                    if (typeof nfinder !== "undefined") {
                        return nfinder;
                    } else {
                        return finder;
                    }
                };

                return finder;
            }
        };

        g_api.SubstanceFinder = g_api.ResourceFinder.builder()
            .resource("substances")
            .extend(function (sfinder) {
                sfinder.searchByExactNameOrCode = function (q) {
                    if (UUID.isUUID(q)) {
                        return sfinder.get(q).andThen(function (s) {
                            return { "content": [s] }
                        });
                    }
                    return sfinder.search("root_names_name:\"^" + q + "$\" OR " +
                        "root_approvalID:\"^" + q + "$\" OR " +
                        "root_codes_code:\"^" + q + "$\"");
                };
                sfinder.getExactStructureMatches = function (smi) {
                    //substances/structureSearch?q=CCOC(N)=O&type=exact
                    var req = g_api.Request.builder()
                        .url(g_api.GlobalSettings.getBaseURL() + "substances/structureSearch")
                        .queryStringData({
                            q: smi,
                            type: "exact",
                            sync: "true" //shouldn't be sync
                        });
                    return g_api.httpProcess(req).andThen(function (tmp) {
                        return tmp;
                    });
                };

                sfinder.searchByExactName = function (q) {
                    return sfinder.search("root_names_name:\"^" + q + "$\"");
                };
            });
        g_api.ReferenceFinder = g_api.ResourceFinder.builder()
            .resource("references")
            .extend(function (rfinder) {
                rfinder.searchByLastEdited = function (q) {
                    return rfinder.search("root_lastEditedBy:\"^" + q + "$\"");
                };
            });

        g_api.CVFinder = g_api.ResourceFinder.builder()
            .resource("vocabularies")
            .extend(function (cvfinder) {
                cvfinder.searchByDomain = function (q) {
                    return cvfinder.search("root_domain:\"^" + q + "$\"");
                };
            });

        g_api.SearchRequest = {
            builder: function () {
                var request = {
                    _limit: 10,
                    _skip: 0,
                    _resource: "resource",
                    _query: ""
                };
                request.limit = function (limit) {
                    request._limit = limit;
                    return request;
                };
                request.skip = function (skip) {
                    request._skip = skip;
                    return request;
                };
                request.top = function (top) {
                    return request.limit(top);
                };
                request.resource = function (resource) {
                    request._resource = resource;
                    return request;
                };
                request.query = function (q) {
                    request._query = q;
                    return request;
                };
                request.asRequest = function () {
                    return g_api.Request.builder()
                        .url(g_api.GlobalSettings.getBaseURL() + request._resource + "/search")
                        .queryStringData({
                            q: request._query,
                            top: request._limit,
                            skip: request._skip
                        });
                };
                request.execute = function () {
                    var httpreq = request.asRequest();
                    return g_api.httpProcess(httpreq);
                };
                return request;
            }
        };


        //TODO
        g_api.SearchResponse = {
            builder: function () {
                var resp = {};
                resp.mix = function (raw) {
                    _.merge(resp, raw);
                    return resp;
                };
                return resp;
            }
        };

        g_api.SubstanceBuilder = {
            fromSimple: function (simple) {
                simple._cache = {};
                simple.getBestID = function () {
                    if (simple._approvalIDDisplay) {
                        return simple._approvalIDDisplay;
                    } else {
                        return simple.uuid;
                    }
                };
                simple.full = function () {
                    //if this is a new record, return self
                    if (!simple.uuid) {
                        return g_api.JPromise.ofScalar(simple);
                    }
                    var req = Request.builder()
                        .url(g_api.GlobalSettings.getBaseURL() + "substances(" + simple.uuid + ")")
                        .queryStringData({
                            view: "full"
                        });
                    return g_api.httpProcess(req);
                };
                simple.fetch = function (field, lambda) {
                    var ret = simple._cache[field];
                    var p = null;
                    if (!ret) {
                        var url = g_api.GlobalSettings.getBaseURL() + "substances(" + simple.uuid + ")/";
                        if (field) {
                            url += field;
                        }
                        var req = g_api.Request.builder()
                            .url(url);
                        p = g_api.httpProcess(req);
                    } else {
                        p = g_api.JPromise.ofScalar(ret);
                    }
                    if (lambda) {
                        return p.andThen(lambda);
                    }
                    return p;
                };
                simple.patch = function () {
                    var p = Patch.builder();

                    if (!simple.uuid) {
                        p = p.setMethod("POST");
                    }

                    //patch overrides but calls the base method
                    p._oldApply = p.apply;
                    p._oldCompute = p.compute;
                    p._oldValidate = p.validate;
                    p.apply = function () {
                        return p._oldApply(simple);
                    };
                    p.compute = function () {
                        return p._oldCompute(simple);
                    };
                    p.validate = function () {
                        return p._oldValidate(simple);
                    };
                    return p;
                };
                return simple;
            }
        };

        g_api.Patch = {
            builder: function () {
                var b = {
                    ops: []
                };

                b.change = function (op) {
                    b.ops.push(op);
                    return b;
                };

                b.replace = function (path, n) {
                    return b.change({
                        op: "replace",
                        path: path,
                        value: n
                    });
                };

                b.remove = function (path) {
                    return b.change({
                        op: "remove",
                        path: path
                    });
                };

                b._method = "PUT";

                //change the method type
                b.setMethod = function (meth) {
                    b._method = meth;
                    return b;
                };

                //Method below is a shot in the dark. TODO: verify!
                b.update = function (path) {
                    return b.change({
                        op: "update",
                        path: path
                    });
                };

                b.add = function (path, n) {
                    return b.change({
                        op: "add",
                        path: path,
                        value: n
                    });
                };

                b.addData = function (data) {
                    return data.addToPatch(b);
                };

                //should return a promise
                b.apply = function (simpleSub) {
                    return simpleSub.full()
                        .andThen(function (ret) {
                            var rr = ret;
                            jsonpatch.apply(rr, b.ops);
                            var methodText = ((b._method) ? b._method : "PUT");
                            console.log('methodText: ' + methodText);
                            var req = g_api.Request.builder()
                                .url(g_api.GlobalSettings.getBaseURL() + "substances")
                                .method(methodText)
                                .body(rr);

                            return g_api.httpProcess(req)
                                //new lines 30 June 2017
                                .andThen(function (r) {
                                    if (r === "") {
                                        return { valid: false, message: "Unexpected error from server" };
                                    } else {
                                        return r;
                                    }
                                });
                        });
                };

                //Calculates the new record, does not submit it
                b.compute = function (simpleSub) {
                    return simpleSub.full()
                        .andThen(function (ret) {
                            var rr = ret;
                            jsonpatch.apply(rr, b.ops);
                            return rr;
                        });
                };

                //Calculates the new record, does not submit it
                b.validate = function (simpleSub) {
                    return simpleSub.full()
                        .andThen(function (ret) {
                            var rr = ret;
                            jsonpatch.apply(rr, b.ops);
                            var req = g_api.Request.builder()
                                .url(g_api.GlobalSettings.getBaseURL() + "substances/@validate")
                                .method("POST")
                                .body(rr);
                            return g_api.httpProcess(req);
                        });
                };

                return b;
            }
        };

        g_api.ResolveWorker = {
            builder: function () {
                var worker = {
                    _list: [],
                    _fetchers: [],
                    _consumer: function (r) { },
                    _finisher: function () { },
                    consumer: function (c) {
                        worker._consumer = c;
                        return worker;
                    },
                    list: function (l) {
                        worker._list = l;
                        return worker;
                    },
                    fetchers: function (f) {
                        worker._fetchers = f;
                        return worker;
                    },
                    finisher: function (f) {
                        worker._finisher = f;
                        return worker;
                    },
                    resolve: function () {
                        var psubs = _.chain(worker._list)
                            .filter(function (r) {
                                return (r.length > 0);
                            })
                            .map(function (r) {
                                var pSub = g_api.SubstanceFinder.searchByExactNameOrCode(r);
                                pSub._q = r;
                                return pSub;
                            })
                            .value();

                        var listener = getListener(psubs.length, function () {
                            worker._finisher();
                        });

                        _.forEach(psubs, function (pSub) {
                            worker.process(pSub, worker._fetchers).get(function (rows) {
                                _.forEach(rows, function (row) {
                                    worker._consumer(row);
                                });
                                listener.decrement();
                            });
                        });
                    },
                    process: function (pSub, fetchNames) {
                        var row = pSub._q;
                        return pSub.andThen(function (ret) {
                            return ret["content"];
                        })
                            .andThen(function (content) {
                                if (content && content.length > 0) {
                                    var promises = _.map(content, function (c) {
                                        return worker.outputAll(g_api.SubstanceBuilder.fromSimple(c), fetchNames);
                                    });
                                    return g_api.JPromise.join(promises).andThen(function (all) {
                                        return _.map(all, function (q) {
                                            return row + "\t" + q;
                                        });
                                    });
                                } else {
                                    return g_api.JPromise.ofScalar([row]);
                                }
                            });
                    },
                    outputAll: function (simpleSub, fetchNames) {
                        return g_api.JPromise.of(function (cb) {
                            g_api.FetcherRegistry.getFetchers(fetchNames)
                                .fetcher(simpleSub)
                                .get(function (g) {
                                    cb(g.join("\t"));
                                });
                        });
                    }
                };
                return worker;
            }
        };

        //TODO: convert to builder pattern
        g_api.FetcherMaker = {
            make: function (name, maker) {
                var fetcher = {
                    name: name,
                    tags: [],
                    fetcher: function (simp) {
                        return g_api.JPromise.of(function (cb) {
                            maker(simp).get(function (ret) {
                                cb(ret, name);
                            });
                        });
                    },
                    andThen: function (after) {
                        return g_api.FetcherMaker.make(name, function (simp) {
                            return fetcher.fetcher(simp).andThen(after);
                        });
                    }
                };
                fetcher.addTag = function (tag) {
                    fetcher.tags.push(tag);
                    return fetcher;
                };
                fetcher.setDescription = function (desc) {
                    fetcher.description = desc;
                    return fetcher;
                };
                return fetcher;
            },
            makeAPIFetcher: function (property, name) {
                var nm = name;
                if (!nm) {
                    nm = property;
                }
                return g_api.FetcherMaker.make(nm, function (simpleSub) {
                    return simpleSub.fetch(property);
                });
            },
            makeScalarFetcher: function (property, name) {
                var nm = name;
                if (!nm) {
                    nm = property;
                }
                return g_api.FetcherMaker.make(nm, function (simpleSub) {
                    return g_api.JPromise.ofScalar(simpleSub[property]);
                });
            },
            makeCodeFetcher: function (codeSystem, name) {
                var nm = name;
                if (!nm) {
                    nm = codeSystem + "[CODE]"
                }
                return g_api.FetcherMaker.make(nm, function (simpleSub) {
                    return simpleSub.fetch("codes(codeSystem:" + codeSystem + ")")
                        .andThen(function (cds) {
                            return _.chain(cds)
                                .sort(function (a, b) {
                                    if (a.type === "PRIMARY" && b.type !== "PRIMARY") {
                                        return -1;
                                    } else if (a.type !== "PRIMARY" && b.type === "PRIMARY") {
                                        return 1
                                    } else {
                                        return 0;
                                    }
                                })
                                .map(function (cd) {
                                    if (cd.type !== "PRIMARY") {
                                        return cd.code + " [" + cd.type + "]";
                                    } else {
                                        return cd.code;
                                    }
                                })
                                .value()
                                .join("; ");
                        });
                });
            }
        };

        g_api.FetcherRegistry = {
            fetchMap: {},
            getFetcher: function (name) {
                var ret = g_api.FetcherRegistry.fetchMap[name];
                return ret;
            },
            addFetcher: function (fetcher) {
                g_api.FetcherRegistry.fetchMap[fetcher.name] = fetcher;
                g_api.FetcherRegistry.fetchers.push(fetcher);
                return g_api.FetcherRegistry;
            },
            fetchers: [],
            //Actually accumulates into a master fetcher 
            getFetchers: function (list) {
                var retlist = _.map(list, function (f) {
                    return g_api.FetcherRegistry.getFetcher(f);
                });
                return g_api.FetcherRegistry.joinFetchers(retlist);
            },
            joinFetchers: function (retlist) {
                return g_api.FetcherMaker.make("Custom", function (simpleSub) {
                    var proms = _.map(retlist, function (r) {
                        return r.fetcher(simpleSub);
                    });
                    var promNames = _.map(retlist, function (r) {
                        return r.name;
                    });

                    return g_api.JPromise.of(function (callback) {
                        g_api.JPromise.join(proms)
                            .get(function (array) {
                                callback(array, promNames);
                            });
                    });
                });
            },
            getFetcherTags: function () {
                var allTags = [];
                _.chain(g_api.FetcherRegistry.fetchers)
                    .map(function (f) {
                        return f.tags;
                    })
                    .forEach(function (tgs) {
                        _.forEach(tgs, function (t) {
                            allTags.push(t);
                        });
                    }).value();
                return _.uniq(allTags);
            },
            getFetchersWithTag: function (tag) {
                return _.chain(g_api.FetcherRegistry.fetchers)
                    .filter(function (f) {
                        return _.indexOf(f.tags, tag) >= 0;
                    })
                    .value();
            },
            getFetchersWithNoTag: function () {
                return _.chain(g_api.FetcherRegistry.fetchers)
                    .filter(function (f) {
                        return f.tags.length === 0;
                    })
                    .value();
            }
        };

        var UUID = {
            randomUUID: function () {
                return UUID.s4() + UUID.s4() + '-' + UUID.s4() + '-' + UUID.s4() + '-' +
                    UUID.s4() + '-' + UUID.s4() + UUID.s4() + UUID.s4();
            },
            s4: function () {
                return Math.floor((1 + Math.random()) * 0x10000)
                    .toString(16)
                    .substring(1);
            },
            isUUID: function (uuid) {
                if ((uuid + "").match(/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/)) {
                    return true;
                }
                return false;
            }
        };

        g_api.UUID = UUID;

        g_api.Request = {
            builder: function () {
                var rq = {
                    _method: "GET"
                };

                rq.url = function (url) {
                    rq._url = url;
                    return rq;
                };
                rq.method = function (method) {
                    rq._method = method;
                    return rq;
                };
                rq.queryStringData = function (q) {
                    rq._q = q;
                    return rq;
                };
                rq.body = function (b) {
                    rq._b = b;
                    return rq;
                };
                return rq;
            }
        };

        //********************************
        //Models
        //********************************

        var CommonData = {
            builder: function () {
                var data = {};

                //should be set
                data._path = "";
                data._type = "";

                //default values
                data.uuid = UUID.randomUUID();
                data.references = [];
                data.access = [];
                data._references = [];

                data.build = function () {
                    var d = JSON.parse(JSON.stringify(data));
                    g_api.gUtil.removeKeysLike(d, /^_/);
                    return d;
                };

                data.setAccess = function (list) {
                    data.access = list;
                    return data;
                };

                data.setProtected = function () {
                    console.log('setProtected called');
                    data.access = ["protected"];
                    return data;
                };

                data.setPublic = function (pub) {
                    if (pub) {
                        console.log('setPublic perceived pub as true. pub: ' + pub);
                        return data;
                    }
                    console.log('setPublic pub as false.');
                    return data.setProtected();
                };

                data.setPreferred = function (preferred) {
                    data.preferred = true;
                    return data;
                };

                data.setDeprecated = function (d) {
                    if (d) {
                        data.deprecated = true;
                    } else {
                        data.deprecated = false;
                    }
                    return data;
                };

                data.addReference = function (r) {
                    if (UUID.isUUID(r)) {
                        data.addReferenceUUID(r);
                    } else {
                        if (r._type === "reference") {
                            data._references.push(r);
                            data.addReferenceUUID(r.uuid);
                        } else {
                            var ref = _.merge(Reference.builder(), r);
                            data._references.push(ref);
                            data.addReferenceUUID(ref.uuid);
                        }
                    }
                    return data;
                };

                data.addReferenceUUID = function (ruuid) {
                    data.references.push(ruuid);
                    return data;
                };

                data.addToPatch = function (patch) {
                    patch = patch.add(data._path, data.build());
                    _.forEach(data._references, function (r) {
                        patch = patch.add("/references/-", r.build());
                    });
                    return patch;
                };

                data.mix = function (source) {
                    _.merge(data, source);
                    return data;
                };

                return data;
            }
        };

        var Name = {
            builder: function () {
                var name = CommonData.builder();
                name._type = "name";
                name._path = "/names/-";

                name.type = "cn";
                name.setName = function (nm) {
                    name.name = nm;
                    return name;
                };
                name.setType = function (type) {
                    name.type = type;
                    return name;
                };
                name.setLanguages = function (lng) {
                    name.languages = lng;
                    return name;
                };
                name.setDomains = function (dmns) {
                    name.domains = dmns;
                    return name;
                };
                name.setNameOrgs = function (orgs) {
                    name.nameOrgs = orgs;
                    return name;
                };


                return name;
            }
        };
        var Code = {
            builder: function () {
                var code = CommonData.builder();
                code._type = "code";
                code._path = "/codes/-";

                code.type = "cn";
                code.setCode = function (cd) {
                    code.code = cd;
                    return code;
                };
                code.setType = function (type) {
                    code.type = type;
                    return code;
                };
                code.setCodeSystem = function (sys) {
                    code.codeSystem = sys;
                    return code;
                };
                code.setCodeComments = function (cmt) {
                    code.comments = cmt;
                    return code;
                };
                code.setUrl = function (url) {
                    code.url = url;
                    return code;
                };

                return code;
            }
        };

        var Reference = {
            builder: function () {
                var ref = CommonData.builder();
                ref._type = "reference";
                ref._path = "references/-";

                ref.setCitation = function (cit) {
                    ref.citation = cit;
                    return ref;
                }
                ref.setUrl = function (url) {
                    ref.url = url;
                    return ref;
                }
                ref.setDocType = function (typ) {
                    ref.docType = typ;
                    return ref;
                }
                ref.setPublicDomain = function (pd) {
                    ref.publicDomain = pd;
                    return ref;
                }

                //@Override
                var oldBuild = ref.build;
                ref.build = function () {
                    var d = oldBuild();
                    delete d.references;
                    return d;
                }
                return ref;
            }
        };

        var Relationship = {
            builder: function () {
                var relationship = CommonData.builder();
                relationship._type = "relationship";
                relationship._path = "/relationships/-";

                relationship.setType = function (type) {
                    relationship.type = type;
                    return relationship;
                };
                relationship.setRelatedSubstance = function (sys) {
                    relationship.relatedSubstance = {
                        "substanceClass": "reference",
                        "refPname": sys._name, "refuuid": sys.uuid, "approvalID": sys.approvalID
                    };
                    var msg = 'in setRelatedSubstance, set refPname to ' + sys._name
                        + '; refuuid to ' + sys.uuid + '; approvalID to ' + sys.approvalID;
                    //alert(msg);
                    return relationship;
                };
                return relationship;
            }
        };

        g_api.CommonData = CommonData;
        g_api.Name = Name;
        g_api.Code = Code;
        g_api.Reference = Reference;
        g_api.Relationship = Relationship;

        var Scripts = {
            scriptMap: {},
            addScript: function (s) {
                Scripts.scriptMap[s.name] = s;
                return Scripts;
            },
            get: function (nm) {
                return Scripts.scriptMap[nm];
            },
            all: function () {
                return _.chain(_.keys(Scripts.scriptMap))
                    .map(function (s) {
                        return Scripts.scriptMap[s];
                    })
                    .value();
            }
        };

        var Script = {
            builder: function () {
                var scr = {};
                scr.argMap = {};
                scr.arguments = [];
                scr.addArgument = function (arg) {
                    if (arg._type !== "argument") {
                        arg = Argument.builder().mix(arg);
                    }
                    scr.arguments.push(arg);
                    scr.argMap[arg.getKey()] = arg;
                    return scr;
                };
                scr.setKey = function (key) {
                    scr.key = key;
                    return scr;
                };
                scr.setName = function (name) {
                    scr.name = name;
                    return scr;
                };
                scr.setDescription = function (desc) {
                    scr.description = desc;
                    return scr;
                };
                scr.mix = function (sc) {
                    _.merge(scr, sc);
                    _.forEach(scr.arguments, function (a) {
                        scr.argMap[a.getKey()] = a;
                    });
                    return scr;
                };
                scr.getArgument = function (narg) {
                    return scr.argMap[narg];
                };

                scr.getArgumentByName = function (narg) {
                    var l = _.filter(scr.arguments, function (a) {
                        return a.name === narg
                    });
                    if (l.length == 0)
                        return undefined;
                    return l[0];
                };
                scr.hasArgumentByName = function (narg) {
                    return !(typeof scr.getArgumentByName(narg) === "undefined");
                };
                scr.hasArgument = function (narg) {
                    return !(typeof scr.getArgument(narg) === "undefined");
                };

                scr.setExecutor = function (exec) {
                    scr.executor = exec;
                    return scr;
                };
                scr.useFor = function (cb) {
                    cb(scr);
                };

                //should return a promise
                //takes a 
                scr.execute = function (vals) {
                    return g_api.JPromise.of(function (cb) {
                        var ret = scr.executor(vals);
                        if (ret && ret._promise) {
                            ret.get(cb);
                        } else {
                            cb(ret);
                        }
                    });

                };
                scr.runner = function () {
                    var cargs = {
                        args: {}
                    };
                    cargs.setValue = function (key, value) {
                        var darg = scr.getArgument(key);
                        if (!darg) {
                            throw "No such argument '" + key + "' in script '" + scr.name + "'";
                        }
                        cargs.args[key] = Argument.builder().mix(scr.getArgument(key)).setValue(value);
                        return cargs;
                    };
                    cargs.setValues = function (kvpairs) {
                        _.forEach(_.keys(kvpairs), function (k) {
                            cargs.setValue(k, kvpairs[k]);
                        });
                        return cargs;
                    };
                    cargs.getArguments = function () {
                        var ret = [];
                        _.forEach(_.keys(cargs.args), function (k) {
                            ret.push(cargs.args[k]);
                        });
                        return ret;
                    };
                    _.forEach(scr.arguments, function (a) {
                        cargs.args[a.getKey()] = a;
                    });


                    cargs.validate = function () {
                        var proms = _.chain(cargs.getArguments())
                            .map(function (a) {
                                return a.validate(cargs);
                            })
                            .value();
                        return g_api.JPromise.join(proms)
                            .andThen(function (plist) {
                                var invalid = _.chain(plist)
                                    .filter(function (v) {
                                        return !v.valid;
                                    })
                                    .value();
                                return invalid;
                            });

                    };

                    cargs.execute = function () {

                        return cargs.validate()
                            .andThen(function (v) {
                                if (v.length == 0) {
                                    return scr.execute(cargs.args)
                                        .andThen(function (r) {
                                            if (typeof r.valid === "undefined") {
                                                return { "valid": true, "message": "Success", "returned": r };
                                            } else {
                                                return r;
                                            }
                                        });
                                } else {

                                    var msg = _.chain(v)
                                        .map(function (mv) {
                                            return mv.message;
                                        })
                                        .value()
                                        .join(";");
                                    return { "valid": false, "message": msg };
                                }
                            })
                    };
                    return cargs;
                };

                return scr;
            }
        };

        var Argument = {
            builder: function () {
                var arg = {};
                arg._type = "argument";
                arg.opPromise = JPromise.ofScalar([]);
                //name of the argument
                arg.setName = function (nm) {
                    arg.name = nm;
                    return arg;
                };

                arg.getName = function () {
                    return arg.name;
                };
                arg.mix = function (ar) {
                    return _.merge(arg, ar);
                };

                arg.validator = function (v) {
                    return g_api.JPromise.ofScalar({ valid: true });
                };

                arg.setRequired = function (r) {
                    arg.required = r;
                    return arg;
                };
                arg.setOptions = function (opPromise) {
                    if (opPromise._promise) {
                        arg.opPromise = opPromise;
                    } else {
                        arg.opPromise = JPromise.ofScalar(opPromise);
                    }
                    return arg;
                };
                arg.getOptions = function () {
                    return arg.opPromise;
                };
                arg.getKey = function () {
                    if (arg.key) {
                        return arg.key;
                    }
                    return arg.name;
                };

                //
                arg.validate = function (cargs) {
                    var validFunction = arg.validator(arg.getValue(), cargs);

                    if (arg.required) {
                        if (_.isUndefined(arg.getValue()) || arg.getValue() === "") {
                            return g_api.JPromise.ofScalar({
                                "valid": false,
                                "message": "Argument '" + arg.getName() + "' must be specified"
                            });
                        }
                    }

                    if (arg.type === "cv") {
                        return arg.opPromise.andThen(function (o) {
                            if (!_.includes(o, arg.getValue())) {
                                return {
                                    "valid": false,
                                    "message": "Argument '" + arg.getName() + "' has value '" + arg.getValue() + "' which is not in the CV"
                                };
                            }

                            return validFunction;
                        });
                    }

                    return validFunction;
                }

                arg.isRequired = function () {
                    if (arg.required) {
                        return true;
                    }
                    var typeVar = typeof arg.defaultValue;

                    return (typerVar === "undefined");

                };

                arg.setDescription = function (des) {
                    arg.description = des;
                    return arg;
                };

                arg.setType = function (type) {
                    arg.type = type;
                    return arg;
                };

                arg.setValue = function (value) {
                    arg.value = value;
                    return arg;
                };
                arg.setDefault = function (def) {
                    arg.defaultValue = def;
                    return arg;
                };
                arg.getValue = function () {
                    if (!_.isUndefined(arg.value)) {
                        return arg.value;
                    } else {
                        return arg.defaultValue;
                    }
                };
                return arg;
            }
        };
        g_api.Scripts = Scripts;
        g_api.Script = Script;
        g_api.Argument = Argument;

        GSRSAPI.initialize(g_api);

        return g_api;
    },
    initialize: function (g_api) {
        _.chain(GSRSAPI.extensions)
            .forEach(function (ex) {
                ex.init(g_api);
            });
    },
    addExtension: function (ext) {
        GSRSAPI.extensions.push(ext);
    },
    extensions: []
}
