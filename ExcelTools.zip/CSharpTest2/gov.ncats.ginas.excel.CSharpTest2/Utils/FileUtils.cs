﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace gov.ncats.ginas.excel.CSharpTest2.Utils
{
    public class FileUtils
    {
        public static string GetJavaScript()
        {
            //String javascriptFilePath = @"C:\ginas_source\Excel\CSharpTest2\gov.ncats.ginas.excel.CSharpTest2\etc\ginas_controller.js";
            string javascriptFilePath = GetCurrentFolder() + @"\etc\ginas_controller.js";
            return System.IO.File.ReadAllText(javascriptFilePath);
        }

        public static string GetHtml()
        {
            Debug.WriteLine("Location: " + System.Reflection.Assembly.GetExecutingAssembly().Location);
            
            String htmlFilePath = GetCurrentFolder() + @"\etc\ginas_controller.html";
            if( !System.IO.File.Exists(htmlFilePath))
            {
                System.Windows.Forms.MessageBox.Show("HTML file not found!");
                return "";
            }
                //@"C:\ginas_source\Excel\CSharpTest2\gov.ncats.ginas.excel.CSharpTest2\etc\ginas_controller.html";
            return File.ReadAllText(htmlFilePath);
        }

        public static string getJQueryCode()
        {
            string filePath = @"C:\downloads\jquery\jquery-1.12.4.js";
            return File.ReadAllText(filePath);
        }
        public static void WriteToFile(string filePath, string stuff)
        {
            File.WriteAllText(filePath, stuff);
        }

        private static string GetCurrentFolder()
        {
            return System.AppDomain.CurrentDomain.BaseDirectory;
        }

    }
}
