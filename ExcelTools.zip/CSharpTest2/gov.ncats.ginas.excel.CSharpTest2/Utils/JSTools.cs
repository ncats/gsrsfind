﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gov.ncats.ginas.excel.CSharpTest2.Utils
{
    public class JSTools
    {
        const int id_length = 10;
        const String id_prefix = "gsrs_";

        public static string RandomIdentifier(int length  = id_length)
        {
            String ident;
            String alpha;
            ident = "";
            alpha = "abcdefghijklmnopqrstuvwxyz";
            Random rnd = new Random();

            int i;

            for( int j = 0; j < length; j++)
            {
                i = rnd.Next(alpha.Length);
                ident = ident + alpha.Substring(i, 1);
            }
            return id_prefix + ident;
        }




    }
}
