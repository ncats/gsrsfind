﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Office.Tools.Ribbon;

using gov.ncats.ginas.excel.CSharpTest2.UI;
using gov.ncats.ginas.excel.CSharpTest2.Model.Callbacks;

namespace gov.ncats.ginas.excel.CSharpTest2
{
    public partial class Ginas
    {
        private void ginas_Load(object sender, RibbonUIEventArgs e)
        {

        }

        private void button1_Click(object sender, RibbonControlEventArgs e)
        {
            Debug.WriteLine("Click handler (debug)");
            Console.WriteLine("Click handler (console)");
            //build up some simple data to test
            string[] testInput = { "BENZYL ALCOHOL", "PHENYLEPHRINE", "NICLOSAMIDE" };
            string searchValue = MakeSearchString(testInput);
            Callback cb = new Callback();
            cb.setKey(Utils.JSTools.RandomIdentifier());
            string searchScript = PrepareSearch(searchValue, cb);
            //searchScript = "cresults['gsrs_sopiiuauvsb']={'keys':function(){return _.keys(this);},'Item':function(k){return this[k];}, 'add':function(k,v){if(!this[k]){this[k]=[];}this[k].push(v);}};ResolveWorker.builder().list(['17199-59-6', '78995-10-5', '78995-14-9']).fetchers(_.map($('div.checkop input:checked'), 'name')).consumer(function(row){cresults['gsrs_sopiiuauvsb'].add(row.split('\t')[0],row);}).finisher(function(){document.title='gsrs_sopiiuauvsb';}).resolve();";
            //searchScript = "cresults['gsrs_sopiiuauvsb']={'keys':function(){return _.keys(this);},'Item':function(k){return this[k];}, 'add':function(k,v){if(!this[k]){this[k]=[];}this[k].push(v);}};ResolveWorker.builder().list([ '17199-59-6', '78995-10-5', '78995-14-9' ]);";
            Debug.WriteLine(searchScript);
            RetrievalForm form = new RetrievalForm();
            form.ScriptToExecute = searchScript;
            form.Show();
        }

        private string MakeSearchString(string[] inputValues)
        {
            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.Append("[");
            List<string> cleanedValues = new List<string>();
            foreach(string value in inputValues)
            {
                cleanedValues.Add("'" + value + "'");
            }
            outputBuilder.Append(string.Join(",", cleanedValues));
            outputBuilder.Append("]");
            
            return outputBuilder.ToString();
        }

        private string PrepareSearch(string searchString, 
            Callback callback)
        {
            string key = callback.getKey();
            StringBuilder scriptBuilder = new StringBuilder();
            //scriptBuilder.Append("window.external.Notify('starting...');");
            scriptBuilder.Append("cresults['");
            scriptBuilder.Append(key);
            scriptBuilder.Append("']={'keys':function(){return _.keys(this);},'Item':function(k){return this[k];}, 'add':function(k,v){if(!this[k]){this[k]=[];}this[k].push(v);}};");
            scriptBuilder.Append("ResolveWorker.builder()");
            //scriptBuilder.Append(".list('$NAMES$'.split('\n'))");
            scriptBuilder.Append(".list($NAMES$)");
            scriptBuilder.Append(".fetchers(_.map(");
            scriptBuilder.Append("$('div.checkop input:checked')");
            //scriptBuilder.Append("getJQueryValue('div.checkop input:checked')");
            scriptBuilder.Append(", 'name'))");
            scriptBuilder.Append(".consumer(function(row){cresults['");
            scriptBuilder.Append(key);
            scriptBuilder.Append("'].add(row.split('\t')[0],row);})");
            //scriptBuilder.Append(".finisher(function(){document.title='");
            scriptBuilder.Append(".finisher(function(){window.external.Notify('");
            
            scriptBuilder.Append(key);
            scriptBuilder.Append("');})");
            scriptBuilder.Append(".resolve();");
            //scriptBuilder.Append('".finisher(function(){window.setTimeout(function(){document.title='" & cb.getKey() & "';},200)})" & _

            string script = scriptBuilder.ToString().Replace("$NAMES$", searchString);
            return script;
            //scriptQueue.enqueue(script)
        }
    }
}
