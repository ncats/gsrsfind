﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;

using gov.ncats.ginas.excel.CSharpTest2.Utils;

namespace gov.ncats.ginas.excel.CSharpTest2.UI
{
    [ComVisible(true)]
    public partial class RetrievalForm : Form
    {
        string _html;
        string _expectedTitle;
        string _baseUrl;
        List<string> _completedScripts = new List<string>();
        const string COMPLETED_DOCUMENT_TITLE = "ginas Tools";

        public RetrievalForm()
        {
            InitializeComponent();
            this.LoadStartup();
        }

        internal void LoadStartup()
        {
            JSTools tools = new JSTools();
            Debug.WriteLine(tools.GetType().FullName);
            string html = Properties.Resources.GinasHTML;
            html = FileUtils.GetHtml();
            string javascript = FileUtils.GetJavaScript(); // Properties.Resources.GinasJavaScript;
            string initURL = Properties.Resources.FallbackURL;
            _baseUrl = initURL;
            html = html.Replace("$GSRS_LIBRARY$", javascript);
            //string jquery = FileUtils.getJQueryCode();
            //html = html.Replace("$JQUERY$", jquery);
            this._html = html;
            //temp:
            FileUtils.WriteToFile(@"c:\temp\debug.html", html);
            _expectedTitle = "g-srs";
            webBrowser1.ObjectForScripting = this;

            webBrowser1.DocumentCompleted += WebBrowser1_DocumentCompleted;
            webBrowser1.Navigate(initURL);
        }

        private void WebBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            Debug.WriteLine("title:" + webBrowser1.DocumentTitle);
            if (webBrowser1.DocumentTitle.Equals(_expectedTitle))
            {
                //load new HTML which will trigger another DocumentCompleted event
                webBrowser1.DocumentText = _html;
            }
            else if (webBrowser1.DocumentTitle.Equals(COMPLETED_DOCUMENT_TITLE))
            {
                ExecuteScript("GlobalSettings.setBaseURL('" + _baseUrl + "api/v1/');");
                if (!string.IsNullOrWhiteSpace(ScriptToExecute))
                {
                    ExecuteScript(ScriptToExecute);
                    _completedScripts.Add(ScriptToExecute);
                    ScriptToExecute = string.Empty;
                }
            }
        }

        public WebBrowser Browser
        {
            get
            {
                return this.webBrowser1;
            }
        }

        public string ScriptToExecute
        {
            set;
            private get;
        }

        public void StartSearch(string searchScript)
        {
            ExecuteScript(searchScript);
        }

        public object ExecuteScript(string script)
        {
            string scriptArg = script;
            string functionName = "runStuff";
            Debug.WriteLine("Going to run script: " + script);
            object returnedValue = webBrowser1.Document.InvokeScript(functionName, new object[] { scriptArg });
            Debug.WriteLine("Return from JS: " + returnedValue);
            return returnedValue;
        }

        public void Notify(string message)
        {
            MessageBox.Show(message, "message from browser");
        }

        public void Proceed(string message)
        {
            Debug.WriteLine(message, "message from browser");
        }
    }
}
