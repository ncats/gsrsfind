﻿namespace gov.ncats.ginas.excel.CSharpTest2
{
    enum OperationType
    {
        None = 0,
        Resolution = 1,
        Loading = 2,
        Other = 3
    }
}