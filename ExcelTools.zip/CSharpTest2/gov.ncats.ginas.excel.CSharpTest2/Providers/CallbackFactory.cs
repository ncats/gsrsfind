﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Office.Interop.Excel;
using gov.ncats.ginas.excel.CSharpTest2.Model.Callbacks;

namespace gov.ncats.ginas.excel.CSharpTest2.Providers
{
    public class CallbackFactory
    {
        public ResolverCallback CreateResolverCallback(Range t)
        {
            ResolverCallback rcall = new ResolverCallback(t); ;
            return rcall;
        }

        public CursorBasedResolverCallback CreateCursorBasedResolverCallback(RangeWrapper t )
        {
            CursorBasedResolverCallback rcall = new CursorBasedResolverCallback(t);
            return rcall;
        }

        public BatchCallback CreateBatchCallback()
        {
            List<Callback> cbs = new List<Callback>();
            return new BatchCallback(cbs);
        }

        //Used to process an update operation
        public UpdateCallback CreateUpdateCallback(Range s)
        {
            return new UpdateCallback(s); ;
        }

        public Callback CreateDummyCallback()
        {
            return new Callback();
        }

    }
}
