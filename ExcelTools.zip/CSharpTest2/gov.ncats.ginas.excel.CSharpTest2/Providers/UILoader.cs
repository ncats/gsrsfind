﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gov.ncats.ginas.excel.CSharpTest2.Providers
{
    internal class UILoader
    {
        internal void LoadUIStuff()
        {
            string html = Properties.Resources.GinasHTML;
            string javascript = Properties.Resources.GinasJavaScript;
            string initURL = Properties.Resources.FallbackURL;
            html = html.Replace("$GSRS_LIBRARY$", javascript);

            UI.RetrievalForm form = new UI.RetrievalForm();

            form.Browser.Navigate(initURL);
            form.Browser.Document.Write(html);
        }
    }
}
