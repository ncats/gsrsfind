﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Office.Interop.Excel;

using gov.ncats.ginas.excel.CSharpTest2.Model;

namespace ginasExcelUnitTests
{
    [TestClass]
    public class ExcelTests
    {
        Application excel;

        [TestInitialize]
        public void SetUp()
        {
            excel = new Application();
            Console.WriteLine("Started Excel");
        }
        [TestCleanup]
        public void Cleanup()
        {
            excel.Quit();
            Console.WriteLine("Closed Excel");
        }
        [TestMethod]
        public void ImageOps_hasComment_Test()
        {
            Workbook book = getExcelSheet();
            Worksheet sheet = book.Worksheets.Item[1];
            Range cellWithComment = sheet.Range["A1"];
            Range cellWithoutComment = sheet.Range["B1"];

            ImageOps imageOps = new ImageOps();
            Assert.IsTrue( imageOps.hascomment(cellWithComment));
            Assert.IsFalse(imageOps.hascomment(cellWithoutComment));
        }

        private Workbook getExcelSheet()
        {
            string sheetFilePath = @"C:\ginas_source\Excel\CSharpTest2\Test_Files\comment test.xlsx";
            Workbook workbook = excel.Workbooks.Open(sheetFilePath);
            return workbook;
        }
    }
}
