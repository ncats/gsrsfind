﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Reflection;
using System.Collections.Generic;

using gov.ncats.ginas.excel.CSharpTest2.Utils;
using gov.ncats.ginas.excel.CSharpTest2.Model.Callbacks;
using ginasExcelUnitTests.Model;
using gov.ncats.ginas.excel.CSharpTest2.Model;

namespace ginasExcelUnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void testBatchCallbackExecute()
        {
            BatchCallback testBatchCallback = setupData();
            ggetMock itemForCallback = new ggetMock();
            testBatchCallback.Execute(itemForCallback);
            Assert.IsTrue(true);//we made it here!
        }

        [TestMethod]
        public void test_RandomIdentifier()
        {
            string newIdString = gov.ncats.ginas.excel.CSharpTest2.Utils.JSTools.RandomIdentifier();
            Console.WriteLine("newId: " + newIdString);
            Assert.IsNotNull(newIdString);
            int expectedLength = 10 + 5;
            Assert.AreEqual(expectedLength, newIdString.Length);

        }

        [TestMethod]
        public void test_getJavaScript()
        {
            string js = FileUtils.GetJavaScript();
            Assert.IsTrue(js.Contains("GSRSAPI") && js.Contains("Script.builder()"));
        }

        [TestMethod]
        public void test_getHTML()
        {
            string html = FileUtils.GetHtml();
            Assert.IsTrue(html.Contains("<textarea id=\"console\">") 
                && html.Contains("_.forEach(runner.getArguments()"));
        }

        [TestMethod]
        public void getTempFile_test()
        {
            ImageOps imageOps = new ImageOps();
            string tempFileName = imageOps.getTempFile("hello", "txt");
            Console.WriteLine("tempFileName: " + tempFileName);
            Assert.IsTrue(tempFileName.EndsWith("txt"));
        }
        private BatchCallback setupData()
        {

            BatchCallback batchCallback = new BatchCallback(new List<Callback>());
            
            Callback cb1 = new Callback();
            cb1.setKey("a");
            batchCallback.addCallback(cb1);
            Callback cb2 = new Callback();
            cb2.setKey("B");
            batchCallback.addCallback(cb2);
            return batchCallback;
        }
    }
}
